# Copyright 2008, 2009 CAMd
# (see accompanying license files for details).

"""Atomic Simulation Environment."""


from ase.atom import Atom
from ase.atoms import Atoms
