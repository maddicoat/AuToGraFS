import numpy as np
from math import pi,isnan
from ase.atom import Atom
from ase.atoms import Atoms
from ase.io import read, write
from collections import deque
from itertools import combinations

def align(mol,model):

    shape = mol.info['shape'].strip()
    model_shape = model.info['shape'].strip()

    #Special processing for octahedra
    if shape == 'octahedral' and model_shape == 'octahedral_2':
        return align_octahedral_2(mol, model) #Trigonal antiprism
    elif shape == 'octahedral' and model_shape == 'octahedral_3':
        return align_octahedral_3(mol, model) #Three corners of a cube
    elif shape == 'octahedral' and model_shape == 'octahedral_4':
        return align_octahedral_4(mol, model) #align one thing exactly, the second thing close enough and assume(!) the rest
    elif shape == 'octahedral' and model_shape == 'tri_prism':
        print "Aligning an octahedron on a trigonal prism!"
        return align_tri_prism(mol, model) 

    if shape == 'square' and model_shape == 'rectangle': #Special case, we want to allow this fairly often
        print "Aligning a square on a rectangle!"
        return align_rectangle(mol, model) 
    

    elif shape != model_shape:
        print shape
        print model_shape
        raise RuntimeError('Molecule shape,'+shape+' and model shape '+model_shape+' not the same')

    if shape == 'ZeroD_cap':
        return align_ZeroD_cap(mol, model)

    if shape == 'point_cap':
        return align_point_cap(mol, model)

    if shape == 'linear':
        return align_linear(mol, model)

    if shape == 'linear_triangle':
        return align_linear_triangle(mol, model)

    if shape == 'triangle':
        return align_triangle(mol, model)

    if shape == 'tetrahedral':
        return align_tetrahedral(mol, model)

    if shape == 'square':
        return align_square(mol, model)

    if shape == 'rectangle':
        return align_rectangle(mol, model)

    if shape == 'trigonal_bipyramid':
        return align_tri_bipyramid(mol, model)

    if shape == 'square_pyramid':
        return align_square_pyramid(mol, model)
    
    if shape == 'octahedral':
        return align_octahedral(mol, model) #square bipyramid

    if shape == 'tri_prism':
        return align_tri_prism(mol, model)
    
    if shape == 'hexagon':
        return align_hexagon(mol, model)

    if shape == 'cube':
        return align_cube(mol, model)

    if shape == 'gyrobifastigium':
        return align_gyrobifastigium(mol, model)

    if shape == 'mfu4': #Kind of an octahedron, kind of not...
        return align_mfu4(mol, model) 
    
    if shape == 'mil53': #special case
        return align_mil53(mol, model) 
    
    if shape == 'cpo27': #another 1D special case
        return align_cpo27(mol, model) 
    
    if shape == 'cuboctahedron':
        return align_cuboctahedron(mol, model) #Zr6
    
    if shape == 'elongated_triangular_orthobicupola':
        return align_elongated_triangular_orthobicupola(mol,model)

    if shape == 'rhombicuboctahedron':
        return align_rhombicuboctahedron(mol, model) #24 vertex "small rhombicuboctahedron"
    
    raise RuntimeError('Molecule shape '+shape+' not known!')

def align_ZeroD_cap(mol, model):
    """ A Zero-Dimensional cap is just a point in space with no alignment. 
        It's intended for use as a 'blind cap' """

    model_cod = model.get_center_of_dummies()
    #Now, the molecule
    mol_dummies = mol.get_atom_indices('X')
    if len(mol_dummies) != 1:
        raise RuntimeError('ZeroD cap has too many dummy atoms!')
    #translate
    mol.translate(model_cod - mol[mol_dummies[0]].position)
    #transfer the tag
    mol[0].tag = model[0].tag

def align_point_cap(mol, model):
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies"""
    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180
    else:
        rot_angle=0
    print "Entering align_point_cap"
    #The model is a Q-X bond: Q is the inner point (imagine M of a paddlewheel), X is the align point as normal
    model_com = model.get_center_of_mass()
    model_cod = model.get_center_of_dummies()
    print "Model COM =", model_com
    print "Model COD =", model_cod
    model_dummy = model.get_atom_indices('X')[0]
    model_vector = (model_cod - model_com)
    #Now, the molecule 
    mol_dummies = mol.get_atom_indices('X')
    if len(mol_dummies) != 1:
        raise RuntimeError('Point cap has too many dummy atoms!')
    mol_bonded_atom=mol[mol_dummies[0]].bondlist.keys()[0] - 1 #remember bondlist is 1-indexed
    #translate
    mol.translate(model_cod - mol[mol_dummies[0]].position)
    #print mol_bonded_atom
    mol_vector = (mol[mol_dummies[0]].position - mol[mol_bonded_atom].position)
    #Now rotate the mol_vector onto the model
    mol.rotate(mol_vector,-model_vector)#,center=mol[mol_dummies[0]].position)
    #Transfer dummy tag
    mol[mol_dummies[0]].tag = model[model_dummy].tag
    #Now, if it has been requested, rotate the molecule about the alignment axis
    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180
        #need a vector perpendicular to the triangle plane
        mol.rotate(-model_vector,rot_angle,center=mol[mol_bonded_atom].position) #pi fudge is because we don't know which way the dihedral is

    return 
    

def align_linear(mol, model):
    eps = 0.02
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies"""
    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180 
    else:
        rot_angle=0   
    model_com = model.get_center_of_mass()
    #mol_com = mol.get_center_of_mass()
    mol_cod = mol.get_center_of_dummies()
    mol.translate(model_com - mol_cod)
    mol_cod = mol.get_center_of_dummies()
    mol_com = mol.get_center_of_mass()
    
    #Grab the tags on the model and sort them asciibetically. We'll use a dict.
    model_dummy_tags={}
    model_tag_indices={}
    for a in model:
        if a.tag:
            model_dummy_tags[a.index]=a.tag
            model_tag_indices[a.tag]=a.index
    mol_dummies = mol.get_atom_indices('X')
    model_atom=min(model_dummy_tags, key=model_dummy_tags.get)
    mol_dummies = mol.get_atom_indices('X')
    if 'flip' in mol.info:  #Biggest rotation
        dummy_distances=[]
        for a in mol_dummies:
            dist=get_intermolecular_distance(model, mol, model_atom, a)
            dummy_distances.append(dist)
        max_index = dummy_distances.index(max(dummy_distances))
        angle = get_general_angle(mol.positions[mol_dummies[max_index]],model_com,model.positions[model_atom])
        if angle > eps:
            mol.rotate(mol.positions[mol_dummies[max_index]]-model_com,model.positions[model_atom]-model_com,center=model_com)
        mol.rotate(mol.positions[mol_dummies[max_index]]-model_com,model.positions[model_atom]-model_com,center=model_com)
        transfer_dummy_tags_linear(mol,model)
        #mol[mol_dummies[min_index]].tag=tag
    else:
        #else: do the smallest rotation
        #print mol_dummies
        dummy_distances=[]
        for a in mol_dummies:
            dist=get_intermolecular_distance(model, mol, model_atom, a)
            dummy_distances.append(dist)
        min_index = dummy_distances.index(min(dummy_distances))
        #max_index = dummy_distances.index(max(dummy_distances))
        #write("pre-aligned_linear.xyz",mol)
        #write("pre-model_linear.xyz",model)
        angle = get_general_angle(mol.positions[mol_dummies[min_index]],model_com,model.positions[model_atom])
        #print "Angle = ",angle
        #print "About to rotate: ", mol.positions[mol_dummies[min_index]]-model_com, model.positions[model_atom]-model_com
        if angle > eps:
            mol.rotate(mol.positions[mol_dummies[min_index]]-model_com,model.positions[model_atom]-model_com,center=model_com)
        transfer_dummy_tags_linear(mol,model)
        #write("semi-aligned_linear.xyz",mol)
        #write("semi-model_linear.xyz",model)
    #by default we'll align such that the furthest atom from the COM and the max component of the moment of inertia are perpendicular,
    #unless we have an extra align point 'Bq' (Bq still has mass=0, so it's useful as a point, but doesn't alter the COM
    model_ghosts = model.get_atom_indices('Bq')
    print "MG #", len(model_ghosts), model_ghosts
    if len(model_ghosts) > 0:
        pass
    else:
        moments=mol.get_moments_of_inertia()
        extra_vec=[0,0,0]
        max_moment = np.argmax(moments)
        extra_vec[max_moment]=1
        mol_com = mol.get_center_of_mass()
        this_vec = mol_com + extra_vec
        furthest_atom = furthest_real(mol)
        #print moments, extra_vec
        dih=get_arbitrary_dihedral(this_vec,mol.positions[mol_dummies[0]],mol.positions[mol_dummies[1]],mol.positions[furthest_atom])
        print "Second rotation: ", dih
        if not np.isnan(dih):
            #print mol.positions
            if 'flip' in mol.info:
                mol.rotate(mol.positions[mol_dummies[0]]-mol.positions[mol_dummies[1]],dih+rot_angle,center=mol_cod) #pi fudge is because we don't know which way the dihedral is
            else:
                mol.rotate(mol.positions[mol_dummies[0]]-mol.positions[mol_dummies[1]],dih+pi+rot_angle,center=mol_cod) #pi fudge is because we don't know which way the dihedral is
            #mol.rotate(mol.positions[mol_dummies[0]]-mol.positions[mol_dummies[1]],dih,center=mol_cod) #pi fudge is because we don't know which way the dihedral is

    #TODO:Also add in a check for the second dummy (if the angle is greater than some epsilon, then spit the dummy)
    return


def align_linear_triangle(mol, model):
    eps = 0.02
    """A linear triangle has two dummies and an alignment point in a triangular config.
       Moves COM_mol to COM_model and aligns dummies."""
    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180 
    else:
        rot_angle=0   
    model_com = model.get_center_of_mass()
    model_cod = model.get_center_of_dummies()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    mol_cod = mol.get_center_of_dummies()
    mol_com = mol.get_center_of_mass()

    #tmpmol = Atoms()
    #tmpmol += model
    #tmpmol += mol
    #write('LT_tmpmol0.xyz',tmpmol)

    #First alignment will align the two COM-COD vectors
    angle = get_general_angle(mol_cod,model_com,model_cod)
    if angle > eps:
        mol.rotate(mol_cod-model_com,model_cod-model_com,center=model_com)

    #tmpmol = Atoms()
    #tmpmol += model
    #tmpmol += mol
    #write('LT_tmpmol1.xyz',tmpmol)
    #Second alignment fixes the dummies
    model_dummy_tags={}
    model_tag_indices={}
    for a in model:
        if a.tag:
            model_dummy_tags[a.index]=a.tag
            model_tag_indices[a.tag]=a.index
    model_dummies = model.get_atom_indices('X')
    mol_dummies = mol.get_atom_indices('X')
    #first dummy to first dummy, we don't care...
    dih=get_arbitrary_dihedral(mol.positions[mol_dummies[0]],model_com,model_cod,model.positions[model_dummies[0]])
    print "Second rotation: ", dih
    if not np.isnan(dih):
        #print mol.positions
        if 'flip' in mol.info:
            mol.rotate(model_cod-model_com,dih+pi,center=model_com) #pi fudge is because we don't know which way the dihedral is
        else:
            mol.rotate(model_cod-model_com,dih,center=model_com)

    #tmpmol = Atoms()
    #tmpmol += model
    #tmpmol += mol
    #write('LT_tmpmol2.xyz',tmpmol)
    transfer_dummy_tags(mol,model)
    return




def align_triangle(mol,model): #new version 07/01/2014 MAA
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
    We'll deal implicitly with equilateral and isosceles """
    eps = 0.02 # on angles, about 1.0 deg
    length_eps = 0.2
    non_planar = False

    #It may be that we're trying to align a triangle that is really a tetrahedron 
    # i.e. three connections, but COM significantly abouve the plane
    # We'll assume this is the case iff the COM and COD differ for *both* the model and mol 
    model_com = model.get_center_of_mass()
    model_cod = model.get_center_of_dummies()
    model_com_cod = np.linalg.norm(model_com - model_cod)
    mol_cod = mol.get_center_of_dummies()
    mol_com = mol.get_center_of_mass()
    mol_com_cod = np.linalg.norm(mol_com - mol_cod)

    #tmpmol = Atoms()
    #tmpmol += model
    #tmpmol += mol
    #write('T_tmpmol0.xyz',tmpmol)
    print "Model COM-COD = ", model_com_cod
    print "Mol COM-COD = ", mol_com_cod
    if model_com_cod > 0.5 and mol_com_cod > 1.0:
        print "Non planar triangle case!"
        non_planar = True
        mol.translate(model_com - mol_com)
        mol_cod = mol.get_center_of_dummies()
        mol_com = mol.get_center_of_mass()
        #First alignment will align the two COM-COD vectors
        angle = get_general_angle(mol_cod,model_com,model_cod)
        if angle > eps:
            mol.rotate(mol_cod-model_com,model_cod-model_com,center=model_com)
        #Now we need to keep this axis fixed
        #We'll assume equilateral and just pick the primary dummies
        model_dummies = model.get_atom_indices('X')
        mol_dummies = mol.get_atom_indices('X')
        dih = get_arbitrary_dihedral(mol[mol_dummies[0]].position,model_cod,model_com,model[model_dummies[0]].position)
        print "Second angle: ", dih    
        if dih > eps:#1.0deg
            print "rotating non-planar triangle"
            mol.rotate(model_cod-model_com,dih,center=model_cod)

    else: 
        model_cod = model.get_center_of_dummies()
        mol_com = mol.get_center_of_dummies()
        mol.translate(model_cod - mol_com)

        tmpmol = Atoms()
        tmpmol += model
        tmpmol += mol
        write('tmpmol0.xyz',tmpmol)
    
        model_dummies = model.get_atom_indices('X')
        mol_dummies = mol.get_atom_indices('X')
        # Now test for equal sides
        #model
        ref_set = ()
        model_sides = np.array([model.get_distance(model_dummies[1],model_dummies[2]), model.get_distance(model_dummies[0],model_dummies[2]), model.get_distance(model_dummies[0],model_dummies[1]) ])
        if abs(model_sides[0] - model_sides[1]) < length_eps and abs(model_sides[0] - model_sides[2]) < length_eps:
            #equilateral
            print "model is approximately equilateral"
            model_primary_index = 0
            model_middle_index = 1
            model_secondary_index = 2
        else:
            model_primary_index = np.argmin(model_sides) #model_sides is rigged such that the index of the array is opposite the side
            model_secondary_index = np.argmax(model_sides) #model_sides is rigged such that the index of the array is opposite the side
            model_middle_index = set([0,1,2]).difference([model_primary_index, model_secondary_index]).pop()
            print "model P/S/M:", model_primary_index, model_secondary_index, model_middle_index
        #mol
        mol_sides = np.array([mol.get_distance(mol_dummies[1],mol_dummies[2]), mol.get_distance(mol_dummies[0],mol_dummies[2]), mol.get_distance(mol_dummies[0],mol_dummies[1]) ])
        if abs(mol_sides[0] - mol_sides[1]) < length_eps and abs(mol_sides[0] - mol_sides[2]) < length_eps:
            #equilateral
            print "mol is approximately equilateral"
            mol_primary_index = 0
            mol_middle_index = 1
            mol_secondary_index = 2
        else:
            mol_primary_index = np.argmin(mol_sides) #mol_sides is rigged such that the index of the array is opposite the side
            mol_secondary_index = np.argmax(mol_sides) #mol_sides is rigged such that the index of the array is opposite the side
            mol_middle_index = set([0,1,2]).difference([mol_primary_index, mol_secondary_index]).pop()
            print "mol P/S/M:", mol_primary_index, mol_secondary_index, mol_middle_index
    
        #First align the first dummy of mol and model
        angle = get_general_angle(mol.positions[mol_dummies[mol_primary_index]],model.positions[model_dummies[model_primary_index]],model_cod)
        angle2 = get_general_angle(model.positions[model_dummies[model_primary_index]],mol.positions[mol_dummies[mol_primary_index]],model_cod)
        print angle, angle2 
        #Has a problem with 180 degree angles - in the case of 180 deg, both the above angles will show up as ~0.0
        print "First angle: ",angle
        if angle < eps and angle2 < eps: #180deg
            print "In Triangle 180degree case"
            v1=mol.positions[mol_dummies[0]]-mol.positions[mol_dummies[2]]  #doing this, because mol_com may not be in same plane as the three dummies
            v2=mol.positions[mol_dummies[1]]-mol.positions[mol_dummies[2]]
            v = np.cross(v1, v2)
            mol.rotate(v,pi,center=model_cod)
        elif angle > eps: #1.0deg:
            mol.rotate(mol[mol_dummies[mol_primary_index]].position-model_cod,model[model_dummies[model_primary_index]].position-model_cod,center=model_cod)
        tmpmol = Atoms()
        tmpmol += model
        tmpmol += mol
        write('tmpmol1.xyz',tmpmol)
        print "getting dihedral:"
        print mol[mol_dummies[mol_secondary_index]].position
        print 
        #Now if not flipped we align last ->last, else last -> middle
        dih = get_arbitrary_dihedral(mol[mol_dummies[mol_secondary_index]].position,model_cod,model[model_dummies[model_primary_index]].position,model[model_dummies[model_secondary_index]].position)
#        if 'flip' not in mol.info:
#            dih = get_arbitrary_dihedral(mol[mol_dummies[mol_secondary_index]].position,model_cod,model[model_dummies[model_primary_index]].position,model[model_dummies[model_secondary_index]].position)
#            #dih = get_arbitrary_dihedral(mol[mol_dummies[mol_middle_index]].position,model[model_dummies[model_middle_index]].position,model[model_dummies[model_secondary_index]].position,mol[mol_dummies[mol_secondary_index]].position)
#        else:
#            #dih = get_arbitrary_dihedral(mol[mol_dummies[mol_middle_index]].position,model[model_dummies[model_secondary_index]].position,model[model_dummies[model_middle_index]].position,mol[mol_dummies[mol_secondary_index]].position) #+pi
#            dih = get_arbitrary_dihedral(mol[mol_dummies[mol_secondary_index]].position,model_cod,model[model_dummies[model_primary_index]].position,model[model_dummies[model_secondary_index]].position)
        print "Second angle: ", dih    
        if dih > eps:#1.0deg
            print "rotating triangle"
            mol.rotate(model[model_dummies[model_primary_index]].position-model_cod,dih,center=model_cod)

        if 'flip' in mol.info:
            print "performing flip"
            mol.rotate(model[model_dummies[model_primary_index]].position-model_cod,pi,center=model_cod)
    #Now, if it has been requested, rotate everything. In this case, things might not match up, but it is a way to align A-B, B-C, C-A
    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180
        #need a vector perpendicular to the triangle plane
        v1=mol.positions[mol_dummies[0]]-mol.positions[mol_dummies[2]]  #doing this, because mol_com may not be in same plane as the three dummies
        v2=mol.positions[mol_dummies[1]]-mol.positions[mol_dummies[2]]
        v = np.cross(v1, v2)
        mol.rotate(v,rot_angle,center=mol_com)

    tmpmol = Atoms()
    tmpmol += model
    tmpmol += mol
    write('tmpmol2.xyz',tmpmol)
    #write('tmpmol.inp',tmpmol)
    print "about to call TDT for new triangle case"
    transfer_dummy_tags_dist(mol,model)
    #print "back from TDT"
    
    #Final translation back to the COM, in case it differs significantly from the COD
    #model_com = model.get_center_of_mass()
    #mol.translate(model_com - model_cod)


    return

#def align_triangle(mol,model): #old version, from way back when tags were alpha
#    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
#    A is primary, C secondary. If tags aren't "A,B,C", then they are sorted ASCIIbetically 
#    and the first and last tags are the primary and secondary alignment respectively"""
#
#    model_com = model.get_center_of_mass()
#    mol_com = mol.get_center_of_dummies()
#    #mol_com = mol.get_center_of_mass()
#    mol.translate(model_com - mol_com)
#    #Grab the tags on the model and sort them asciibetically. We'll use a dict.
#    model_dummy_tags={}
#    model_tag_indices={}
#    for a in model:
#        if a.tag:
#            model_dummy_tags[a.index]=a.tag
#            model_tag_indices[a.tag]=a.index
#    mol_dummies = mol.get_atom_indices('X')
#    #Flipping the molecule in this case means we align A-A, then B-C and C-B
#    if 'flip' in mol.info:  #
#        print "Triangle: flipped alignment"
#        model_atom=min(model_dummy_tags, key=model_dummy_tags.get)
#        mol_dummies = mol.get_atom_indices('X')
#        dummy_distances={}
#        for a in mol_dummies:
#            dist=get_intermolecular_distance(model, mol, model_atom, a)
#            dummy_distances[a] = dist
#        min_index = min(dummy_distances, key=dummy_distances.get)
#        mol.rotate(mol.positions[min_index]-model_com,model.positions[model_atom]-model_com,center=model_com)
#        fixed_A = min_index
#        #And the second rotation
#        model_atom=max(model_dummy_tags, key=model_dummy_tags.get)
#        dummy_distances={}
#        for a in mol_dummies:
#            dist=get_intermolecular_distance(model, mol, model_atom, a)
#            dummy_distances[a] = dist
#        max_index = max(dummy_distances, key=dummy_distances.get) #dummy_distances.index(min(dummy_distances))
#        if max_index == fixed_A:
#        #remove the value from the dist and extract the next one
#            del dummy_distances[max_index]
#            max_index = max(dummy_distances, key=dummy_distances.get) #there was a min here, typo?
#        mol.rotate(mol.positions[max_index]-model_com,model.positions[model_atom]-model_com,center=model_com)
#    else:
#        print "Triangle: normal alignment"
#        model_atom=min(model_dummy_tags, key=model_dummy_tags.get)
#        mol_dummies = mol.get_atom_indices('X')
#        dummy_distances={}
#        for a in mol_dummies:
#            dist=get_intermolecular_distance(model, mol, model_atom, a)
#            dummy_distances[a] = dist
#        min_index = min(dummy_distances, key=dummy_distances.get)
#        angle = get_general_angle(model.positions[model_atom],mol.positions[min_index],model_com)
#        if angle > 0.02:
#            print 'angle = ', angle, "doing rotation"
#            mol.rotate(mol.positions[min_index]-model_com,model.positions[model_atom]-model_com,center=model_com)
#        fixed_A = min_index
#        #And the second rotation
#        model_atom=max(model_dummy_tags, key=model_dummy_tags.get)
#        dummy_distances={}
#        for a in mol_dummies:
#            dist=get_intermolecular_distance(model, mol, model_atom, a)
#            dummy_distances[a] = dist
#            #print dummy_distances
#        min_index = min(dummy_distances, key=dummy_distances.get) #dummy_distances.index(min(dummy_distances))
#        if min_index == fixed_A:
#        #remove the minimum value from the dist and extract the next one
#            del dummy_distances[min_index]
#            min_index = min(dummy_distances, key=dummy_distances.get)
#        angle = get_general_angle(model.positions[model_atom],mol.positions[min_index],model_com)
#        if angle > 0.02:
#            print 'angle = ', angle, "doing rotation"
#            mol.rotate(mol.positions[min_index]-model_com,model.positions[model_atom]-model_com,center=model_com)
#    #Now, if it has been requested, rotate everything. In this case, things might not match up, but it is a way to align A-B, B-C, C-A
#    if 'rotate' in mol.info:
#        rot_angle = mol.info['rotate'] * pi / 180
#        #need a vector perpendicular to the triangle plane
#        v1=mol.positions[mol_dummies[0]]-mol.positions[mol_dummies[2]]  #doing this, because mol_com may not be in same plane as the three dummies
#        v2=mol.positions[mol_dummies[1]]-mol.positions[mol_dummies[2]]
#        v = np.cross(v1, v2)
#        mol.rotate(v,rot_angle,center=mol_com) #pi fudge is because we don't know which way the dihedral is
#
#    print "about to call TDT for a triangle case"
#    transfer_dummy_tags_dist(mol,model)
#    #print "back from TDT"
#    return    


def align_tetrahedral(mol,model):
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies."""
   #old: A is primary, D secondary. If tags aren't "A,B,C,D", then they are sorted ASCIIbetically 
   #old: and the first and last tags are the primary and secondary alignment respectively"""
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_dummies()
    print "AT:",mol_com
    mol.translate(model_com - mol_com)
    #Grab the tags on the model and sort them asciibetically. We'll use a dict.
    model_dummy_tags={}
    model_tag_indices={}
    for a in model:
        #print a
        if a.tag :
            model_dummy_tags[a.index]=a.tag
            model_tag_indices[a.tag]=a.index
    print "MDT", model_dummy_tags        
    mol_dummies = mol.get_atom_indices('X')
    #We align on the first (ASCIIbetical) model atom
    model_atom=min(model_dummy_tags, key=model_dummy_tags.get)
    mol_dummies = mol.get_atom_indices('X')
    dummy_distances={}
    for a in mol_dummies:
        dist=get_intermolecular_distance(model, mol, model_atom, a)
        dummy_distances[a] = dist
    if 'flip' in mol.info:  #Flipped in the case of a tetrahedron means max-min alignment i.e. D-A, then closest and the other two work themsevles out
        print "Tetrahedron: flipped alignment"
        max_index = max(dummy_distances, key=dummy_distances.get)
        mol.rotate(mol.positions[max_index]-model_com,model.positions[model_atom]-model_com,center=model_com)
        #write("first_aligned_tetrahedron.xyz",mol)
        fixed_A = max_index
        fixed_axis = mol.positions[max_index]-model_com
    else:
        print "Tetrahedron: normal alignment" #min-min alignment
        min_index = min(dummy_distances, key=dummy_distances.get)
        mol.rotate(mol.positions[min_index]-model_com,model.positions[model_atom]-model_com,center=model_com)
        #write("first_aligned_tetrahedron.xyz",mol)
        fixed_A = min_index
        fixed_axis = mol.positions[min_index]-model_com
    #Second rotation is the same regardless of the first    
    #And the second rotation, we'll use angle and axis to ensure the first axis stays
        model_atom=max(model_dummy_tags, key=model_dummy_tags.get)
        dummy_distances={}
    for a in mol_dummies:
        dist=get_intermolecular_distance(model, mol, model_atom, a)
        dummy_distances[a] = dist
    min_index = min(dummy_distances, key=dummy_distances.get) #dummy_distances.index(min(dummy_distances))
    if min_index == fixed_A:
        #remove the minimum value from the dist and extract the next one
        del dummy_distances[min_index]
        min_index = min(dummy_distances, key=dummy_distances.get)
    angle=get_arbitrary_dihedral(mol.positions[min_index],model_com,mol.positions[fixed_A],model.positions[model_atom])
    mol.rotate(fixed_axis,angle,center=model_com)
    #print "about to call TDT"
    
    #So rotation here assumes the first fixed axis, meaning that A-A and A-D alignment are possible, but not A-B or A-C
    #Need to add a "fix-axis" option??
    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180 
        mol.rotate(fixed_axis,rot_angle,center=model_com)

    #transfer_dummy_tags(mol,model)
    transfer_dummy_tags_dist(mol,model)
    #print "back from TDT"
    #write("aligned_tetrahedron.xyz",mol)
    #write("model_tetrahedron.xyz",model)
    #print mol.get_tags()
    return    

def align_square(mol,model):
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies"""
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    #We can pick our two alignment points straight up
    model_dummies = model.get_atom_indices('X')
    intra_model_distances = {}
    for dindex in model_dummies:
        this_dist = model.get_distance(model_dummies[0],dindex)
        intra_model_distances[dindex] = this_dist
    print intra_model_distances
    sorted_IModelD = sorted(intra_model_distances, key=intra_model_distances.get)
    model_X1 = model_dummies[0] # pick the first dummy to align on
    model_X2 = sorted_IModelD[1] # pick the closest dummy to the first one, must be a 90deg one 
    #mol
    mol_dummies = mol.get_atom_indices('X')
    intra_mol_distances = {}
    for dindex in mol_dummies:
        this_dist = mol.get_distance(mol_dummies[0],dindex)
        intra_mol_distances[dindex] = this_dist
    print intra_mol_distances
    sorted_IMolD = sorted(intra_mol_distances, key=intra_mol_distances.get)
    mol_X1 = mol_dummies[0] # pick the first dummy to align on
    mol_X2 = sorted_IMolD[1] # pick the closest dummy to the first one, must be a 90deg one 
    #Now we can do the rotation
    angle1 = get_general_angle(mol.positions[mol_X1],model_com,model.positions[model_X1])
    print "angle1 = ", angle1
    this_angle = angle_2vectors(mol.positions[mol_X1]-model_com , model.positions[model_X1]-model_com)
    print "this_angle = ", this_angle
    if angle1 > 0.02 and abs(angle1 - pi) >0.02:
        if 'flip' in mol.info:
            mol.rotate(mol.positions[mol_X1]-model_com,-model.positions[model_X1]-model_com,center=model_com)
        else:
            mol.rotate(mol.positions[mol_X1]-model_com,model.positions[model_X1]-model_com,center=model_com)

    #write("semi-aligned_square.xyz",mol)
    #write("semi-model_square.xyz",model)
    #Second rotation 
    angle2 = get_general_angle(mol.positions[mol_X2],model_com,model.positions[model_X2])
    print "angle2 = ", angle2
    if angle2 > 0.02 and abs(angle2 - pi) >0.02:
        mol.rotate(mol.positions[mol_X2]-model_com,model.positions[model_X2]-model_com,center=model_com)

    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180
        #need a vector perpendicular to the square plane
        v1=mol.positions[mol_dummies[0]]-mol.positions[mol_dummies[2]]  #doing this, because mol_com may not be in same plane as the three dummies
        v2=mol.positions[mol_dummies[1]]-mol.positions[mol_dummies[2]]
        v = np.cross(v1, v2)
        mol.rotate(v,rot_angle,center=mol_com)

    write("aligned_square.xyz",mol)
    write("model_square.xyz",model)
    #Now transfer the tags
    transfer_dummy_tags_dist(mol,model)    

    return

def align_square_old(mol,model): #something is broken here, second alignment is not always happening 17/02/14 MAA
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies"""
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    #Grab the tags on the model and sort them asciibetically. We'll use a dict.
    write("pre-aligned_square.xyz",mol)
    write("pre-model_square.xyz",model)
    model_dummy_tags={}
    model_tag_indices={}
    for a in model:
        if a.tag:
            model_dummy_tags[a.index]=a.tag
            model_tag_indices[a.tag]=a.index
    #We align on the first (ASCIIbetical) model atom
    model_atom=min(model_dummy_tags, key=model_dummy_tags.get)
    mol_dummies = mol.get_atom_indices('X')
    dummy_distances={}
    for a in mol_dummies:
        dist=get_intermolecular_distance(model, mol, model_atom, a)
        dummy_distances[a] = dist 
    min_index = min(dummy_distances, key=dummy_distances.get)  
    angle1 = get_general_angle(mol.positions[min_index],model_com,model.positions[model_atom])
    #print "First angle is ", angle1
    if angle1 > 0.02:
        mol.rotate(mol.positions[min_index]-model_com,model.positions[model_atom]-model_com,center='COM')
    #Now we have COM_mol in the right place, and point 'A' aligned, need to do a second rotation to align the second point
    #Flipped, in the case of a square, keeps A (and therefore C), but switches B and D
    fixed_A = min_index
    fixed_axis = mol.positions[min_index]-model_com
    #print "First model atom is ", model_atom
    #print "First mol atom is ", mol_dummies[min_index]
    #Select a new model atom. Closest to the one we just used (either one)
    for a in model:
        if a.index != model_atom and a.symbol == 'X':
            dist=model.get_distance(model_atom, a.index)
            print model_atom, a.index, dist
            dummy_distances[a.index] = dist 
    model_atom = min(dummy_distances, key=dummy_distances.get)  
    #print "Second model atom is ", model_atom
    #Now, there should be one of the dummy atoms in the molecule that is closer to D (or whatever the max tag is) than the one we just aligned with A
    #If they're the same, then the molecule is 90deg rotated from what it should be (along the QA axis).
    #Nevertheless, we'll check
    dummy_distances={}
    for a in mol_dummies:
        if a != fixed_A:
            print model_atom, a
            dist=mol.get_distance(fixed_A, a)
            #dist=get_intermolecular_distance(model, mol, model_atom, a)# can fail
            dummy_distances[a] = dist
    #print "DD= ",fixed_A,dummy_distances
    min_index = min(dummy_distances, key=dummy_distances.get) #dummy_distances.index(min(dummy_distances))
    #print "Second mol atom is ", min_index
    #check_angle = get_general_angle(mol.positions[fixed_A],model_com,mol.positions[min_index]) 
    #check_angle2 = get_general_angle(model.positions[model_atom],model[0].position,mol.positions[min_index]) 
    #check_angle3 = get_general_angle(model.positions[model_atom],model_com,mol.positions[min_index]) 
    #print "check = ", check_angle
    #print "pseudo dihedral = ", check_angle2, check_angle3
    #print "COM?", model_com, model[0].position
    #model[model_atom].symbol = 'Cl'
    #mol[min_index].symbol = 'Cl'
    #if min_index == fixed_A:
    #    #remove the minimum value from the dist and extract the next one
    #    del dummy_distances[min_index] 
    #    min_index = min(dummy_distances, key=dummy_distances.get)    
    #Now finally do the second rotation
    #write("semi-aligned_square.xyz",mol)
    #write("semi-model_square.xyz",model)
    #model[model_atom].symbol = 'X'
    #mol[min_index].symbol = 'X'
    print mol.positions[min_index],mol.positions[fixed_A],model.positions[model_atom]
    angle=get_arbitrary_dihedral(mol.positions[min_index],mol.positions[fixed_A],model_com,model.positions[model_atom])
    print "Angle= ", angle
    if 'flip' in mol.info:
        print "Square: flipped alignment"
        mol.rotate(fixed_axis,angle+pi,center=model_com)
    else:
        print "Square: normal alignment"
        mol.rotate(fixed_axis,angle,center=model_com)

    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180
        #need a vector perpendicular to the square plane
        v1=mol.positions[mol_dummies[0]]-mol.positions[mol_dummies[2]]  #doing this, because mol_com may not be in same plane as the three dummies
        v2=mol.positions[mol_dummies[1]]-mol.positions[mol_dummies[2]]
        v = np.cross(v1, v2)
        mol.rotate(v,rot_angle,center=mol_com) 

    #Add in a debug_print somewhere about the other two angles (i.e. how far the structure is from being actually square)
    transfer_dummy_tags_dist(mol,model)
    
    #write("aligned_square.xyz",mol)
    #write("model_square.xyz",model)
    return

def align_rectangle(mol,model):
    """Moves COM_mol to COM_model and then rotates the molecule to align the midpoints of pairs of dummies"""
    eps = 0.02 #angles

    #model_com = model.get_center_of_mass()
    model_com = model.get_center_of_dummies()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    print "fragID =", mol[0].fragmentID
    # Now locate the model dummies and determine their midpoints
    model_midpoints = Atoms()
    model_dummies = model.get_atom_indices('X')
    model_Q = model.get_atom_indices('Q')
    model_midpoints.append(model[model_Q[0]])
    for a1 in range(len(model_dummies)):
        for a2 in range(a1+1,len(model_dummies)):
            this_midpoint = model[model_dummies[a1]].position + (model[model_dummies[a2]].position - model[model_dummies[a1]].position)/2
            #D = model[model_Q[0]].position - this_midpoint
            D = model_com - this_midpoint
            if np.linalg.norm(D) > 0.25: 
                model_midpoints.append(Atom('X',position=this_midpoint))
    # Now locate the mol dummies and determine their midpoints
    mol_midpoints = Atoms()
    mol_midpoints.append(model[model_Q[0]])
    mol_dummies = mol.get_atom_indices('X')
    for a1 in range(len(mol_dummies)):
        #mol_midpoints.append(Atom('X',position=mol[mol_dummies[a1]].position))
        for a2 in range(a1+1,len(mol_dummies)):
            print "Midpoints"
            this_midpoint = mol[mol_dummies[a1]].position + (mol[mol_dummies[a2]].position - mol[mol_dummies[a1]].position)/2
            print mol[mol_dummies[a1]].position, mol[mol_dummies[a2]].position, this_midpoint 
            #D = model[model_Q[0]].position - this_midpoint # still use the model Q, should be the same as mol.COM
            D = model_com - this_midpoint # still use the model Q, should be the same as mol.COM
            if np.linalg.norm(D) > 0.2: 
                mol_midpoints.append(Atom('N',position=this_midpoint))
    #Now we align on the long axis
    #write('modelR_midpoints.xyz',model_midpoints)
    #write('molR_midpoints.xyz',mol_midpoints)
    model_midpoint_distances = {}
    for a in model_midpoints:
        if a.symbol is not 'Q':
            dist=model_midpoints.get_distance(0,a.index)
            model_midpoint_distances[a.index] = dist
    model_max_index = max(model_midpoint_distances, key=model_midpoint_distances.get)
    model_min_index = min(model_midpoint_distances, key=model_midpoint_distances.get)
    print model_midpoint_distances
    print "model",model_min_index, model_max_index
    #molecule...
    mol_midpoint_distances = {}
    for a in mol_midpoints:
        if a.symbol is not 'Q':
            dist=mol_midpoints.get_distance(0,a.index)
            mol_midpoint_distances[a.index] = dist
    mol_max_index = max(mol_midpoint_distances, key=mol_midpoint_distances.get)
    mol_min_index = min(mol_midpoint_distances, key=mol_midpoint_distances.get) 
    #write("model_midpoints.xyz",model_midpoints)
    #In case of some weird geometries (notably chs1), the min and max index aren't perpendicular, which creates hassles with the second dihedral
    intra_model_angles = {}
    for d1 in model_midpoints:
        if d1.symbol != 'Q':
            this_angle = get_general_angle(model_midpoints[model_max_index].position, model_com, d1.position)
            print "TA =", model_max_index, d1.index, this_angle
            if abs(this_angle -  pi/2) < eps:
                model_perp_index = d1.index
                break
    #Now mol
    #print "Finding mol perp index"
    intra_mol_angles = {}
    for d1 in mol_midpoints:
        if d1.symbol != 'Q':
            this_angle = get_general_angle(mol_midpoints[mol_max_index].position, model_com, d1.position)
            #print d1, this_angle, pi/2
            if abs(this_angle -  pi/2) < eps*25: #Need to be quite slack here to take into account things that aren't centrosymmetric
                #print "selecting ", d1.index
                mol_perp_index = d1.index
                break

    print mol_midpoint_distances
    print "mol",mol_min_index, mol_max_index
    #Now actually align
    #write('model'+`mol[0].fragmentID`+'_prealigned.xyz',model)
    #write('mol'+`mol[0].fragmentID`+'_prealigned.xyz',mol)
    angle = get_general_angle(mol_midpoints.positions[mol_max_index],model_midpoints.positions[model_max_index],model_com)
    print "1st angle =", angle
    if angle > 0.02 and abs(angle -  pi) > eps: #about a degree
        mol.rotate(mol_midpoints.positions[mol_max_index]-model_com,model_midpoints.positions[model_max_index]-model_com,center='COM')
        mol_midpoints.rotate(mol_midpoints.positions[mol_max_index]-model_com,model_midpoints.positions[model_max_index]-model_com,center='COM')
    #if 'rotate' in mol.info:
    #    print "Rectangle: rotated alignment"
    #    mol.rotate(mol_midpoints.positions[mol_max_index]-model_com,model_com-model_midpoints.positions[model_max_index],center='COM') #reverse of the rotation above
    #    mol_midpoints.rotate(mol_midpoints.positions[mol_max_index]-model_com,model_com-model_midpoints.positions[model_max_index],center='COM') #reverse of the rotation above
    fixed_axis = mol_midpoints.positions[mol_max_index]-model_com
    #Then the short axis
    #write('model'+`mol[0].fragmentID`+'_semialigned.xyz',model)
    #write('mol'+`mol[0].fragmentID`+'_semialigned.xyz',mol)
    #write('molR_midpoints1.xyz',mol_midpoints)
    #molecule again...
    print "After 1st rotation",mol_midpoint_distances
    print "mol",mol_perp_index, mol_max_index
    angle = get_arbitrary_dihedral(mol_midpoints.positions[mol_perp_index],model_com,mol_midpoints.positions[mol_max_index],model_midpoints.positions[model_perp_index])
    print "2nd angle =", angle
    #mol_wtf = Atoms()
    #mol_wtf.append(Atom('He',position=mol_midpoints.positions[mol_min_index]))
    #mol_wtf.append(Atom('He',position=model_com))
    #mol_wtf.append(Atom('He',position=mol_midpoints.positions[mol_max_index]))
    #mol_wtf.append(Atom('He',position=model_midpoints.positions[model_min_index]))
    #write("alignR_dih.xyz",mol_wtf)
    if 'flip' in mol.info:
        print "Rectangle: flipped alignment"
        if angle > 0.02 and abs(angle -  pi) > eps:
            mol.rotate(fixed_axis, angle,center=model_com)
            mol.rotate(fixed_axis, pi,center=model_com)

        else:
            mol.rotate(fixed_axis,pi,center=model_com)
    else:
        print "Rectangle: normal alignment"
        print abs(angle -  pi)
        if angle > 0.02 and abs(angle -  pi) > eps:
            print "Rotating by ",angle
            mol.rotate(fixed_axis,angle,center=model_com)

    if 'rotate' in mol.info:
        print "Rectangle: rotating last step"
        rot_angle = mol.info['rotate'] * pi / 180
        v1=mol.positions[mol_dummies[0]]-mol.positions[mol_dummies[2]]  #doing this, because mol_com may not be in same plane as the three dummies
        v2=mol.positions[mol_dummies[1]]-mol.positions[mol_dummies[2]]
        v = np.cross(v1, v2)
        mol.rotate(v, rot_angle,center=model_com)

    #write('model'+`mol[0].fragmentID`+'_aligned.xyz',model)
    #write('mol'+`mol[0].fragmentID`+'_aligned.xyz',mol)

    #transfer the dummy tags based on distance only
    transfer_dummy_tags_dist(mol,model)

    return


def align_tri_bipyramid(mol, model): #Half tested MAA 30/01/2014. Model and mol will align but not all cases tested. 
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies"""
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    eps=0.1
    length_eps = 0.1
    # sort both the model and mol dummies into set of 3 (triangle plane) and set of 2 (main axis)
    #model first
    model_dummies = model.get_atom_indices('X')
    intra_model_distances = {}
    for dindex in model_dummies:
        this_dist = model.get_distance(0,dindex)
        intra_model_distances[dindex] = this_dist
    print intra_model_distances
    sorted_IMD = sorted(intra_model_distances, key=intra_model_distances.get)
    #If all five distances are the same, we need to test on angles
    intra_model_angles = {}
    if all(abs(intra_model_distances[index] - intra_model_distances[sorted_IMD[0]]) < eps for index in intra_model_distances.keys()):
        print "TBP model distances all equal."
        for d1 in model_dummies:
            for d2 in model_dummies:
                this_angle = get_general_angle(model[d1].position, model_com, model[d2].position)
                if abs(this_angle -  pi) < eps:
                    model_axial_indices = [d1,d2]
                    model_radial_indices = [dx for dx in model_dummies if dx not in model_axial_indices]
                    break
    else:
        #Now, there are two options, tri-bipyramid is tall and skinny (axis ditances longer than radial distances) or short and fat.
        #The long and skinny option is more likely, but we'll allow for both options
        model_axial_indices = [sorted_IMD[3],sorted_IMD[4]]
        model_radial_indices = [sorted_IMD[0],sorted_IMD[1],sorted_IMD[2]]
        print "Axial ", model_axial_indices
        print "Radial ", model_radial_indices
        #Is this assignment ok? Test that all three radial distances are the same
        if not all(abs(intra_model_distances[index] - intra_model_distances[sorted_IMD[0]]) < eps for index in model_radial_indices):
            #Then the assignement is wrong - we have a short and fat case
            print "TBP model assignment failed, reassigning!"
            model_axial_indices = [sorted_IMD[0],sorted_IMD[1]]
            model_radial_indices = [sorted_IMD[2],sorted_IMD[3],sorted_IMD[4]]
    #mol 
    mol_dummies = mol.get_atom_indices('X')
    intra_mol_distances = {}
    for dindex in mol_dummies:
        D = mol[dindex].position - model_com
        this_dist = np.linalg.norm(D)
        intra_mol_distances[dindex] = this_dist
    print intra_mol_distances
    sorted_IMD = sorted(intra_mol_distances, key=intra_mol_distances.get)
    #If all five distances are the same, we need to test on angles
    #intra_mol_angles = {}
    if all(abs(intra_mol_distances[index] - intra_mol_distances[sorted_IMD[0]]) < eps for index in intra_mol_distances.keys()):
        print "TBP mol distances all equal."
        for d1 in mol_dummies:
            for d2 in mol_dummies:
                this_angle = get_general_angle(mol[d1].position, model_com, mol[d2].position)
                if abs(this_angle -  pi) < eps:
                    mol_axial_indices = [d1,d2]
                    mol_radial_indices = [dx for dx in mol_dummies if dx not in mol_axial_indices]
                    break
    else:
        #Now, there are two options, tri-bipyramid is tall and skinny (axis ditances longer than radial distances) or short and fat.
        #The long and skinny option is more likely, but we'll allow for both options
        mol_axial_indices = [sorted_IMD[3],sorted_IMD[4]]
        mol_radial_indices = [sorted_IMD[0],sorted_IMD[1],sorted_IMD[2]]
        #Is this assignment ok? Test that all three radial distances are the same
        if not all(abs(intra_mol_distances[index] - intra_mol_distances[sorted_IMD[0]]) < eps for index in mol_radial_indices):
            #Then the assignement is wrong - we have a short and fat case
            print "TBP mol assignment failed, reassigning!"
            mol_axial_indices = [sorted_IMD[0],sorted_IMD[1]]
            mol_radial_indices = [sorted_IMD[2],sorted_IMD[3],sorted_IMD[4]]
    #So now we can define our axes and do the first rotation
    #but the second rotation can be tricky if the radial triange isn't equilateral, so let's interrogate that first
    #model
    model_sides = np.array([model.get_distance(model_radial_indices[1],model_radial_indices[2]), model.get_distance(model_radial_indices[0],model_radial_indices[2]), model.get_distance(model_radial_indices[0],model_radial_indices[1]) ])
    if abs(model_sides[0] - model_sides[1]) < length_eps and abs(model_sides[0] - model_sides[2]) < length_eps:
        #equilateral
        print "model is approximately equilateral"
        model_primary_index = model_radial_indices[0]
        #model_middle_index = model_radial_indices[1]
        #model_secondary_index = model_radial_indices[2]
    else:
        model_primary_index = model_radial_indices[np.argmax(model_sides)] #model_sides is rigged such that the index of the array is opposite the side
        #model_secondary_index = model_radial_indices[np.argmin(model_sides)] #model_sides is rigged such that the index of the array is opposite the side
        #model_middle_index = model_radial_indices[set([,1,2]).difference([model_primary_index, model_secondary_index]).pop()]
        #print "model P/S/M:", model_primary_index, model_secondary_index, model_middle_index
    print "model primary index = ",model_primary_index
    #mol
    mol_sides = np.array([mol.get_distance(mol_radial_indices[1],mol_radial_indices[2]), mol.get_distance(mol_radial_indices[0],mol_radial_indices[2]), mol.get_distance(mol_radial_indices[0],mol_radial_indices[1]) ])
    if abs(mol_sides[0] - mol_sides[1]) < length_eps and abs(mol_sides[0] - mol_sides[2]) < length_eps:
        #equilateral
        print "mol is approximately equilateral"
        mol_primary_index = mol_radial_indices[0]
        #mol_middle_index = mol_radial_indices[1]
        #mol_secondary_index = mol_radial_indices[2]
    else:
        mol_primary_index = mol_radial_indices[np.argmax(mol_sides)] #mol_sides is rigged such that the index of the array is opposite the side
        #mol_secondary_index = mol_radial_indices[np.argmin(mol_sides)] #mol_sides is rigged such that the index of the array is opposite the side
        #mol_middle_index = mol_radial_indices[set([0,1,2]).difference([mol_primary_index, mol_secondary_index]).pop()]
        #print "mol P/S/M:", mol_primary_index, mol_secondary_index, mol_middle_index
    print "mol primary index = ",mol_primary_index

    #Normal orientation will go sorted_IModelD[0] to sorted_IMolD[0] - not lexicographic, but it doesn't really matter
    if 'flip' in mol.info:
        print "Trigonal bipyramid: flipped alignment"
        mol.rotate(mol[mol_axial_indices[0]].position-model_com,model[model_axial_indices[1]].position-model_com,center='COM') #D3h axes now aligned
        #Now we need to rotate in the triangle plane. We can use an angle rather than a dihedral
        this_angle = get_general_angle(model[model_radial_indices[0]].position,model_com,mol[mol_radial_indices[0]].position)
        print "Second angle =", this_angle
        mol.rotate(model[model_axial_indices[1]].position-model_com,this_angle,center='COM') 
    else:
        print "Trigonal bipyramid: normal alignment"
        mol.rotate(mol[mol_axial_indices[0]].position-model_com,model[model_axial_indices[0]].position-model_com,center='COM') #D3h axes now aligned
        #Now we need to rotate in the triangle plane. We can use an angle rather than a dihedral
        write('model5_semialigned.xyz',model)
        write('mol5_semialigned.xyz',mol)
        this_angle = get_general_angle(model[model_radial_indices[0]].position,model_com,mol[mol_radial_indices[0]].position)
        print "Second angle =", this_angle
        mol.rotate(mol[mol_primary_index].position-model_com,model[model_primary_index].position-model_com,center='COM') 


    #Any extra rotation is defined as being around the D3 axis
    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180
        mol.rotate(model[model_axial_indices[0]].position-model_com,rot_angle,center=model_com)

    write('model5_aligned.xyz',model)
    write('mol5_aligned.xyz',mol)
    #transfer the dummy tags
    transfer_dummy_tags_dist(mol,model)

    return

def align_square_pyramid(mol, model): #30/11/2014 MAA
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies"""
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    eps=0.1
    # sort both the model and mol dummies into set of 4 (triangle plane) and set of 1 (main axis)
    # distances are too complicated here (too many cases of short vs. long)
    # model first, finding the dummy that has approximately equal angles to all other dummies
    model_dummies = model.get_atom_indices('X')
    intra_model_angle_diffs = {}
    for d1 in model_dummies:
        these_angles = [] 
        for d2 in model_dummies:
            if d2 != d1:
                this_angle = get_general_angle(model[d1].position, model_com, model[d2].position)
                these_angles.append(this_angle)
        this_diff = max(these_angles) - min(these_angles)
        intra_model_angle_diffs[d1] = this_diff
    model_unique_index = min(intra_model_angle_diffs, key=intra_model_angle_diffs.get)
    # now mol 
    mol_dummies = mol.get_atom_indices('X')
    intra_mol_angle_diffs = {}
    for d1 in mol_dummies:
        these_angles = [] 
        for d2 in mol_dummies:
            if d2 != d1:
                this_angle = get_general_angle(mol[d1].position, mol_com, mol[d2].position)
                these_angles.append(this_angle)
        this_diff = max(these_angles) - min(these_angles)
        intra_mol_angle_diffs[d1] = this_diff
    mol_unique_index = min(intra_mol_angle_diffs, key=intra_mol_angle_diffs.get)
    #write('model'+`mol[0].fragmentID`+'_prealigned.xyz',model)
    #write('mol'+`mol[0].fragmentID`+'_prealigned.xyz',mol)
    print "Model Unique Index =", model_unique_index
    print "Mol Unique Index =", mol_unique_index
    angle = get_general_angle(mol.positions[mol_unique_index],model_com,model.positions[model_unique_index])
    print "First angle =", angle
    if angle > 0.02: # and abs(angle -  pi) > eps:
        #if angle > 0.02:#1.0:
        print "Rotating square pyramid axis to axis"
        mol.rotate(mol.positions[mol_unique_index]-model_com,model.positions[model_unique_index]-model_com,center=model_com)
    # And fix this axis
    fixed_axis = mol.positions[mol_unique_index]-model_com
    # Now, do we have a square or a rectangle?
    # We'll align like a rectangle anyway
    model_dummies.remove(model_unique_index)
    mol_dummies.remove(mol_unique_index)
    # Now locate the midpoints of the model dummies 
    model_midpoints = Atoms()
    model_Q = model.get_atom_indices('Q')
    model_midpoints.append(model[model_Q[0]])
    for a1 in range(len(model_dummies)):
        for a2 in range(a1+1,len(model_dummies)):
            this_midpoint = model[model_dummies[a1]].position + (model[model_dummies[a2]].position - model[model_dummies[a1]].position)/2
            #D = model[model_Q[0]].position - this_midpoint
            D = model_com - this_midpoint
            if np.linalg.norm(D) > 0.25:
                model_midpoints.append(Atom('X',position=this_midpoint))
    # Now locate the mol dummies and determine their midpoints
    mol_midpoints = Atoms()
    mol_midpoints.append(model[model_Q[0]])
    for a1 in range(len(mol_dummies)):
        #mol_midpoints.append(Atom('X',position=mol[mol_dummies[a1]].position))
        for a2 in range(a1+1,len(mol_dummies)):
            print "Midpoints"
            this_midpoint = mol[mol_dummies[a1]].position + (mol[mol_dummies[a2]].position - mol[mol_dummies[a1]].position)/2
            print mol[mol_dummies[a1]].position, mol[mol_dummies[a2]].position, this_midpoint
            #D = model[model_Q[0]].position - this_midpoint # still use the model Q, should be the same as mol.COM
            D = model_com - this_midpoint # still use the model Q, should be the same as mol.COM
            if np.linalg.norm(D) > 0.2:
                mol_midpoints.append(Atom('N',position=this_midpoint))
    #Now we align on the long axis
    #write('modelR_midpoints.xyz',model_midpoints)
    #write('molR_midpoints.xyz',mol_midpoints)
    model_midpoint_distances = {}
    for a in model_midpoints:
        if a.symbol is not 'Q':
            dist=model_midpoints.get_distance(0,a.index)
            model_midpoint_distances[a.index] = dist
    model_max_index = max(model_midpoint_distances, key=model_midpoint_distances.get)
    model_min_index = min(model_midpoint_distances, key=model_midpoint_distances.get)
    print model_midpoint_distances
    print "model",model_min_index, model_max_index
    #molecule...
    mol_midpoint_distances = {}
    for a in mol_midpoints:
        if a.symbol is not 'Q':
            dist=mol_midpoints.get_distance(0,a.index)
            mol_midpoint_distances[a.index] = dist
    mol_max_index = max(mol_midpoint_distances, key=mol_midpoint_distances.get)
    mol_min_index = min(mol_midpoint_distances, key=mol_midpoint_distances.get)
    # Now we do the second alignment
    angle = get_arbitrary_dihedral(mol_midpoints.positions[mol_max_index],model_com,mol.positions[mol_unique_index],model_midpoints.positions[model_max_index])
    print "2nd angle =", angle
    if angle > 0.02 and abs(angle -  pi) > eps:
        print "Rotating by ",angle
        mol.rotate(fixed_axis,angle,center=model_com)

    #write('model'+`mol[0].fragmentID`+'_aligned.xyz',model)
    #write('mol'+`mol[0].fragmentID`+'_aligned.xyz',mol)

    #transfer the dummy tags based on distance only
    transfer_dummy_tags_dist(mol,model) 
    
    return


def align_octahedral(mol,model):
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies"""
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    eps=0.1
    #first we get the tags for the model, our model must have one unequal (shorter) axis that identifies it as the unique/first ("C") axis
    model_distances={}
    for i in range(len(model)):
        if  model[i].tag: #and model[i].tag > 0:#not model[i].tag.endswith("\""): #len(model[i].tag) ==1:
            model_distances[model[i].tag]=model.get_distance(i,0)
            #model_tags[model.get_distance(i,0)]=model[i].tag #may be non-unique but we don't care
            print model[i].tag, model_distances[model[i].tag]
        #print model_tags
    print model_distances
    #print sorted(model_distances, key=lambda key: model_distances[key])    
    first_tag=sorted(model_distances, key=lambda key: model_distances[key])[0]
    last_tag=sorted(model_distances, key=lambda key: model_distances[key])[2]
    print first_tag
    #Now find the dummy that is closest in distance to the model atom with tag 'C'
    #C is our unique axis
    model_atom = int(model.get_tag_indices(first_tag)[0])
    #print model_atom
    mol_dummies = mol.get_atom_indices('X')
    #print mol_dummies 
    print "atom to com distances"
    dummy_distances={}
    for a in mol_dummies:
        dist=get_intermolecular_distance(model, mol, 0, a) #0 is the COM
        dummy_distances[a] = dist 
        print mol[a].index, dist
    print dummy_distances    
    min_index = min(dummy_distances, key=dummy_distances.get)  
    print "AlignOct: min_index =", min_index
    #write('translated_octahedron2.xyz',mol)
    #write('translated_model2.xyz',model)
    #angle = get_general_angle(mol.positions[min_index],model.positions[model_atom],model_com)
    #print "B",angle ,mol.positions[min_index],model.positions[model_atom],model_com
    #print "B",mol.positions[min_index]-model_com, model.positions[model_atom]-model_com
    #rotating by a near-zero angle will cause numericl problems
    angle = get_general_angle(mol.positions[min_index],model.positions[model_atom],model_com)
    if angle > 0.02:#1.0:
        mol.rotate(mol.positions[min_index]-model_com,model.positions[model_atom]-model_com,center='COM')
    #write('translated_octahedron3.xyz',mol)
    #write("semi_aligned_model.xyz",model)
    #write("semi_aligned_octahedron.xyz",mol)
    angle = get_general_angle(mol.positions[min_index],model.positions[model_atom],model_com)
    #print angle ,mol.positions[min_index],model.positions[model_atom],model_com
    #print mol.positions[min_index]-model_com, model.positions[model_atom]-model_com
    fixed_axis=mol.positions[min_index]-model_com
    #Flipping the molecule in this case means we align C-C'
    if 'flip' in mol.info:
        print "Octahedron: flipping primary axis"
        mol.rotate(mol.positions[min_index]-model_com,pi,center='COM')
    #Now we have COM_mol in the right place, and  the smallest axis aligned, we'll do the biggest
    model_atom = int(model.get_tag_indices(last_tag)[0])
    max_index = max(dummy_distances, key=dummy_distances.get)  
    angle = get_general_angle(mol.positions[max_index],model.positions[model_atom],model_com)
    print "Second angle: ",angle
    #Now finally do the second rotation
    if angle > 0.02:#1.0:
        mol.rotate(mol.positions[max_index]-model_com,model.positions[model_atom]-model_com,center='COM')
    #mol[min_index].tag='B'
    #Add in a debug_print somewhere about the other two angles (i.e. how far the structure is from being actually square)
    #Now, if it has been requested, rotate everything. In this case, C axis stays, A,B rotate
    if 'rotate' in mol.info:
        #rotating around the major axis 
        rot_angle = mol.info['rotate'] * pi / 180
        mol.rotate(fixed_axis,rot_angle,center=model_com)
    
    transfer_dummy_tags_dist(mol,model)
    #write("aligned_model.xyz",model)
    #write("aligned_octahedron.xyz",mol)
    print mol.get_tags()
    return

def align_octahedral_2(mol,model):
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
    This is the second octahedron option. Aligns a trigonal antiprism."""
    eps = 0.1
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    model_dummy_tags={}
    model_tag_indices={}
    for a in model:
        if a.tag:
            model_dummy_tags[a.index]=a.tag
            model_tag_indices[a.tag]=a.index
    model_dummies = model.get_atom_indices('X')
    #First we need to align on the D3d axis of the molecule, otherwise we can end up with a mis-alignment.
    #So, lets find them. We'll use a purely geometric means
    #Basically we'll take the model atom, and find the distances to all the other dummies, there will be:
    #two short distances: two guys on the same face - these are the guys we want 
    #two medium distances: opposite face but not directly through the COM 
    #one long distance: guy directly opposite, through the COM
    intra_model_distances = {}
    for dindex in model_dummies:
        this_dist = model.get_distance(model_dummies[0],dindex)
        intra_model_distances[dindex] = this_dist
    print intra_model_distances
    sorted_IMD = sorted(intra_model_distances, key=intra_model_distances.get) 
    #This assignment fails if the tri_antiprism is short and fat rather than tall and skinny
    model_face1_indices = [sorted_IMD[0],sorted_IMD[1],sorted_IMD[2]]
    model_face2_indices = [sorted_IMD[3],sorted_IMD[4],sorted_IMD[5]]
    #Test face1
    diff1 = abs(model.get_distance(model_face1_indices[2],model_face1_indices[1]) - model.get_distance(model_face1_indices[2],model_face1_indices[0]))
    diff2 = abs(model.get_distance(model_face1_indices[1],model_face1_indices[0]) - model.get_distance(model_face1_indices[1],model_face1_indices[2]))
    if diff1 < eps and diff2 < eps:
        print "Assignment ok!"
    else:
        #we have a short, fat guy (2 medium - we want these, two small and one big)  
        print "Assignment failed, reassigning!"
        model_face1_indices = [sorted_IMD[0],sorted_IMD[3],sorted_IMD[4]]
        model_face2_indices = [sorted_IMD[2],sorted_IMD[3],sorted_IMD[5]]
    model_face1 = Atoms('X3',positions=[model[model_face1_indices[0]].position,model[model_face1_indices[1]].position,model[model_face1_indices[2]].position])
    model_face2 = Atoms('X3',positions=[model[model_face2_indices[0]].position,model[model_face2_indices[1]].position,model[model_face2_indices[2]].position])
    #Now the same trick for the molecule:
    mol_dummies = mol.get_atom_indices('X')
    intra_mol_distances = {}
    for dindex in mol_dummies:
        this_dist = mol.get_distance(mol_dummies[0],dindex)
        intra_mol_distances[dindex] = this_dist
    print intra_mol_distances
    sorted_IMD = sorted(intra_mol_distances, key=intra_mol_distances.get)
    #This assignment fails if the tri_antiprism is short and fat rather than tall and skinny
    mol_face1_indices = [sorted_IMD[0],sorted_IMD[1],sorted_IMD[2]]
    mol_face2_indices = [sorted_IMD[3],sorted_IMD[4],sorted_IMD[5]]
    #Test face1
    diff1 = abs(mol.get_distance(mol_face1_indices[2],mol_face1_indices[1]) - mol.get_distance(mol_face1_indices[2],mol_face1_indices[0]))
    diff2 = abs(mol.get_distance(mol_face1_indices[1],mol_face1_indices[0]) - mol.get_distance(mol_face1_indices[1],mol_face1_indices[2]))
    if diff1 < eps and diff2 < eps:
        print "Mol assignment ok!"
    else:
        #we have a short, fat guy (2 medium - we want these, two small and one big)
        print "Mol assignment failed, reassigning!"
        mol_face1_indices = [sorted_IMD[0],sorted_IMD[3],sorted_IMD[4]]
        mol_face2_indices = [sorted_IMD[2],sorted_IMD[3],sorted_IMD[5]]
    mol_face1 = Atoms('X3',positions=[mol[mol_face1_indices[0]].position,mol[mol_face1_indices[1]].position,mol[mol_face1_indices[2]].position])
    mol_face2 = Atoms('X3',positions=[mol[mol_face2_indices[0]].position,mol[mol_face2_indices[1]].position,mol[mol_face2_indices[2]].position])
    #Now find the centroids of the mol and model faces. We only need one for each
    model_centroid1 = model_face1.get_center_of_dummies()
    mol_centroid1 = mol_face1.get_center_of_dummies()
    
    if 'flip' in mol.info:
        print "Trimeric SBU: flipped alignment"
        mol.rotate(mol_centroid1-model_com,-model_centroid1-model_com,center='COM') #D3d axes now aligned
        #Now we need to such that mol_dummy, model_axis and model dummy are in the same plane
        dih=get_arbitrary_dihedral(mol[mol_face1_indices[0]].position,model_centroid1,model_com,model[model_face1_indices[0]].position)
        mol.rotate(model_centroid1-model_com,-dih + (60 * pi / 180),center='COM') #use the model centroid as the centroid is not updated, add rotation of 60 deg
    else:
        print "Trimeric SBU: normal alignment"
        mol.rotate(mol_centroid1-model_com,model_centroid1-model_com,center='COM') #D3d axes now aligned
        #write('model3_semialigned.xyz',model)
        #write('mol3_semialigned.xyz',mol)
        #Now we need to such that mol_dummy, model_axis and model dummy are in the same plane
        dih=get_arbitrary_dihedral(mol[mol_face1_indices[0]].position,model_centroid1,model_com,model[model_face1_indices[0]].position)
        mol.rotate(model_centroid1-model_com,-dih,center='COM') #use the model centroid as the centroid is not updated
    #Any extra rotation is defined as being around the D3d axis
    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180
        mol.rotate(model_centroid1-model_com,rot_angle,center=model_com)

    #write('model3_aligned.xyz',model)
    #write('mol3_aligned.xyz',mol)
    #transfer the dummy tags
    transfer_dummy_tags_dist(mol,model)

    return


def align_octahedral_3(mol,model): #This fails sometimes. Use octahedron_2 instead
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
    This is the third octahedron option. Aligns six corners of a cube."""
    eps = 0.1
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    model_dummy_tags={}
    model_tag_indices={}
    for a in model:
        if a.tag:
            model_dummy_tags[a.index]=a.tag
            model_tag_indices[a.tag]=a.index
    model_dummies = model.get_atom_indices('X')
    #First select a pair of opposite dummies. Doesn't matter which
    intra_model_distances = {}
    for dindex in model_dummies:
        this_dist = model.get_distance(model_dummies[0],dindex)
        intra_model_distances[dindex] = this_dist
    print intra_model_distances
    sorted_ImodelD = sorted(intra_model_distances, key=intra_model_distances.get)
    opp_dummy = sorted_ImodelD[5]
    #Now the same trick for the molecule:
    mol_dummies = mol.get_atom_indices('X')
    intra_mol_distances = {}
    for dindex in mol_dummies:
        this_dist = mol.get_distance(mol_dummies[0],dindex)
        intra_mol_distances[dindex] = this_dist
    print intra_mol_distances
    sorted_ImolD = sorted(intra_mol_distances, key=intra_mol_distances.get)
    opp_dummy = sorted_ImolD[5]
    #Now we can align on the first axis
    if 'flip' not in mol.info:
        print "Octahedral SBU (3): normal alignment"
        mol.rotate(mol[sorted_ImolD[0]].position-model_com,model[sorted_ImodelD[0]].position-model_com,center='COM') #defined axes now aligned
    else:
        print "Octahedral SBU (3): flipped alignment"
        mol.rotate(mol[sorted_ImolD[5]].position-model_com,model[sorted_ImodelD[0]].position-model_com,center='COM') #defined axes now aligned
    #Now we need to align such that the other two pairs are equally misaligned
    model_midpoint = model[sorted_ImodelD[1]].position + (model[sorted_ImodelD[4]].position - model[sorted_ImodelD[1]].position)/2 #shortest + (second longest - shortest)/2
    mol_midpoint = mol[sorted_ImolD[1]].position + (mol[sorted_ImolD[4]].position - mol[sorted_ImolD[1]].position)/2 #shortest + (second longest - shortest)/2
    #Now we align these two midpoints about the first axis
    dih = get_arbitrary_dihedral(mol_midpoint,model_com,model[sorted_ImodelD[0]].position,model_midpoint)
    mol.rotate(model[sorted_ImodelD[0]].position-model_com,-dih,center='COM')

    #write('model3_aligned.xyz',model)
    #write('mol3_aligned.xyz',mol)

    transfer_dummy_tags_dist(mol,model)

    return

def align_octahedral_4(mol,model): #There are some peculiarly distorted octahedra around
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
    This is the fourth octahedron option. Aligns first dummy exactly, second to the plane 
    and assumes(!) the rest. This is effectively a failsafe option. Align won't die, but
    the results may be... interesting.
    Flip option is ignored."""

    eps = 0.1
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    model_dummy_tags={}
    model_tag_indices={}
    model_dummies = model.get_atom_indices('X')
    mol_dummies = mol.get_atom_indices('X')
    print "OA4: ", len(mol), mol_dummies[0], len(model), model_dummies[0]
    #First align the first dummy of mol and model
    angle = get_general_angle(mol.positions[mol_dummies[0]],model.positions[model_dummies[0]],model_com)
    print "First angle: ",angle
    if angle > 0.02:#1.0deg:
        mol.rotate(mol[mol_dummies[0]].position-model_com,model[model_dummies[0]].position-model_com,center=model_com)
    #Now find the closest dummy to the one aligned
    intra_model_distances = {}
    for dindex in model_dummies:
        this_dist = model.get_distance(model_dummies[0],dindex)
        intra_model_distances[dindex] = this_dist
    print intra_model_distances
    sorted_ImodelD = sorted(intra_model_distances, key=intra_model_distances.get)
    nearest_model_dummy = sorted_ImodelD[1]
    #Now the same trick for the molecule:
    intra_mol_distances = {}
    for dindex in mol_dummies:
        this_dist = mol.get_distance(mol_dummies[0],dindex)
        intra_mol_distances[dindex] = this_dist
    print intra_mol_distances
    sorted_ImolD = sorted(intra_mol_distances, key=intra_mol_distances.get)
    nearest_mol_dummy = sorted_ImolD[1]
    #Now we can do the second alignment
    dih = get_arbitrary_dihedral(mol[nearest_mol_dummy].position,model_com,model[sorted_ImodelD[0]].position,model[nearest_model_dummy].position)
    if dih > 0.02:#1.0deg
        mol.rotate(model[model_dummies[0]].position-model_com,dih,center=model_com)


    transfer_dummy_tags_dist(mol,model)

    return

def align_tri_prism(mol,model):
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies"""
    eps = 0.1
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    #Grab the tags on the model and sort them asciibetically. We'll use a dict.
    model_dummy_tags={}
    model_tag_indices={}
    for a in model:
        if a.tag:
            model_dummy_tags[a.index]=a.tag
            model_tag_indices[a.tag]=a.index
    model_dummies = model.get_atom_indices('X')
    #First we need to align on the D3h axis of the molecule, otherwise we can end up with a mis-alignment.
    #So, lets find them. We'll use a purely geometric means
    #Basically we'll take the model atom, and find the distances to all the other dummies, there will be:
    #one short distance: guy immediately below
    #two medium distances: two guys on the same face - these are the guys we want
    #two long distances: guys on the opposite face and not immediately below
    intra_model_distances = {}
    for dindex in model_dummies:
        this_dist = model.get_distance(model_dummies[0],dindex)
        intra_model_distances[dindex] = this_dist
    print intra_model_distances
    sorted_IMD = sorted(intra_model_distances, key=intra_model_distances.get)
    #This assignment fails if the tri_prism is tall and skinny rather than short and fat
    model_face1_indices = [model_dummies[0],sorted_IMD[2],sorted_IMD[3]]
    model_face2_indices = [sorted_IMD[1],sorted_IMD[4],sorted_IMD[5]]
    #Test face1
    diff1 = abs(model.get_distance(model_face1_indices[2],model_face1_indices[1]) - model.get_distance(model_face1_indices[2],model_face1_indices[0]))
    diff2 = abs(model.get_distance(model_face1_indices[1],model_face1_indices[0]) - model.get_distance(model_face1_indices[1],model_face1_indices[2]))
    #print model.get_distance(model_face1_indices[2],model_face1_indices[1]), model.get_distance(model_face1_indices[2],model_face1_indices[0])
    #print model.get_distance(model_face1_indices[1],model_face1_indices[0]),model.get_distance(model_face1_indices[1],model_face1_indices[2])
    #print abs(model.get_distance(model_face1_indices[2],model_face1_indices[1]) - model.get_distance(model_face1_indices[2],model_face1_indices[0]))
    #print abs(model.get_distance(model_face1_indices[1],model_face1_indices[0]) - model.get_distance(model_face1_indices[1],model_face1_indices[2]))
    if diff1 < eps and diff2 < eps:
        print "Assignment ok!"
    else:
        #we have a tall, skinny guy
        print "Assignment failed, reassigning!"
        model_face1_indices = [sorted_IMD[0],sorted_IMD[1],sorted_IMD[2]]
        model_face2_indices = [sorted_IMD[3],sorted_IMD[4],sorted_IMD[5]]
    print "model 1", model_face1_indices
    print "model 2", model_face2_indices
    model_face1 = Atoms('X3',positions=[model[model_face1_indices[0]].position,model[model_face1_indices[1]].position,model[model_face1_indices[2]].position])
    model_face2 = Atoms('X3',positions=[model[model_face2_indices[0]].position,model[model_face2_indices[1]].position,model[model_face2_indices[2]].position])
    #Now the same trick for the molecule:
    mol_dummies = mol.get_atom_indices('X')
    intra_mol_distances = {}
    for dindex in mol_dummies:
        this_dist = mol.get_distance(mol_dummies[0],dindex)
        intra_mol_distances[dindex] = this_dist
    print intra_mol_distances
    sorted_IMD = sorted(intra_mol_distances, key=intra_mol_distances.get)
    mol_face1_indices = [mol_dummies[0],sorted_IMD[2],sorted_IMD[3]]
    mol_face2_indices = [sorted_IMD[1],sorted_IMD[4],sorted_IMD[5]]
    print "mol 1", mol_face1_indices
    print "mol 2", mol_face2_indices
    #Same check for the molecule
    #Test face1
    diff1 = abs(mol.get_distance(mol_face1_indices[2],mol_face1_indices[1]) - mol.get_distance(mol_face1_indices[2],mol_face1_indices[0]))
    diff2 = abs(mol.get_distance(mol_face1_indices[1],mol_face1_indices[0]) - mol.get_distance(mol_face1_indices[1],mol_face1_indices[2]))
    if diff1 < eps and diff2 < eps:
        print "Mol Assignment ok!"
    else:
        #we have a tall, skinny guy
        print "Mol Assignment failed, reassigning!"
        mol_face1_indices = [sorted_IMD[0],sorted_IMD[1],sorted_IMD[2]]
        mol_face2_indices = [sorted_IMD[3],sorted_IMD[4],sorted_IMD[5]]
    
    mol_face1 = Atoms('X3',positions=[mol[mol_face1_indices[0]].position,mol[mol_face1_indices[1]].position,mol[mol_face1_indices[2]].position])
    mol_face2 = Atoms('X3',positions=[mol[mol_face2_indices[0]].position,mol[mol_face2_indices[1]].position,mol[mol_face2_indices[2]].position])
    #Now find the centroids of the mol and model faces. We only need one for each
    model_centroid1 = model_face1.get_center_of_dummies()
    mol_centroid1 = mol_face1.get_center_of_dummies()
    print model_centroid1
    print mol_centroid1
    #write('model3_prealigned.xyz',model)
    #write('mol3_prealigned.xyz',mol)
    #Now we finally get to actually aligning stuff
    if 'flip' in mol.info:
        print "Trimeric SBU: flipped alignment"
        mol.rotate(mol_centroid1-model_com,-model_centroid1-model_com,center='COM') #D3h axes now aligned
        #Now we need to such that mol_dummy, model_axis and model dummy are in the same plane
        dih=get_arbitrary_dihedral(mol[mol_face1_indices[0]].position,model_centroid1,model_com,model[model_face1_indices[0]].position)
        mol.rotate(model_centroid1-model_com,-dih,center='COM') #use the model centroid as the centroid is not updated
    else:
        print "Trimeric SBU: normal alignment"
        mol.rotate(mol_centroid1-model_com,model_centroid1-model_com,center='COM') #D3h axes now aligned
        #write('model3_semialigned.xyz',model)
        #write('mol3_semialigned.xyz',mol)
        #Now we need to such that mol_dummy, model_axis and model dummy are in the same plane
        dih=get_arbitrary_dihedral(mol[mol_face1_indices[0]].position,model_centroid1,model_com,model[model_face1_indices[0]].position)
        mol.rotate(model_centroid1-model_com,-dih,center='COM') #use the model centroid as the centroid is not updated
    #Any extra rotation is defined as being around the D3h axis
    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180
        mol.rotate(model_centroid1-model_com,rot_angle,center=model_com)

    #write('model3_aligned.xyz',model)
    #write('mol3_aligned.xyz',mol)
    #transfer the dummy tags 
    transfer_dummy_tags_dist(mol,model)    

    return

#def align_hexagon(mol,model): #13/01/2016 Using moments of inertia
#    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies
#       using moments of inertia"""
#
#    eps = 0.02 #on agles, about 1 deg
#    model_com = model.get_center_of_mass()
#    mol_com = mol.get_center_of_mass()
#    mol.translate(model_com - mol_com)
#    
#    # Get moments
#    model_MoI = model.get_moments_of_inertia(vectors=True)
#    mol_MoI = mol.get_moments_of_inertia(vectors=True)

    #

#
#    get_moments_of_inertia(vectors=True)
#

def align_hexagon(mol,model): #New 08/04/2014
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
    We find the midpoint of each pair of tags and then align like a triangle.""" # Hexagons are often irregular
    eps = 0.02 #on agles, about 1 deg
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    ####
    print "model MoI:"
    print model.get_masses()
    #need to alter our dummy masses here
    new_model_masses = []
    for m in model:
        if m.symbol == "Q":
            new_model_masses.append(1000.0)
        elif m.symbol == "X":
            new_model_masses.append(10.0)
        else:
            new_model_masses.append(None)
    model.set_masses(new_model_masses)
    print model.get_masses()
    model_moi = model.get_moments_of_inertia(vectors=True)
    print model.get_moments_of_inertia(vectors=True)
    print model.get_moments_of_inertia(vectors=True)[0]
    #need to alter our dummy masses here
    new_mol_masses = []
    for m in mol:
        if m.symbol == "Q":
             new_mol_masses.append(1000.0)
        elif m.symbol == "X":
             new_mol_masses.append(100.0)
        else:
             new_mol_masses.append(0.0)
    mol.set_masses(new_mol_masses)
    print "mol MoI:"
    print mol.get_moments_of_inertia(vectors=True)
    mol_moi = mol.get_moments_of_inertia(vectors=True)
    ###
    #now determine position of max and min eigenvalues
    model_max_evalue = np.argmax(model.get_moments_of_inertia(vectors=True)[0])
    model_min_evalue = np.argmin(model.get_moments_of_inertia(vectors=True)[0])
    mol_max_evalue = np.argmax(mol.get_moments_of_inertia(vectors=True)[0])
    mol_min_evalue = np.argmin(mol.get_moments_of_inertia(vectors=True)[0])
    model_mid_evalue = 3 - (model_max_evalue + model_min_evalue)
    mol_mid_evalue = 3 - (mol_max_evalue + mol_min_evalue)
    print model_max_evalue, model_mid_evalue, model_min_evalue, mol_max_evalue, mol_mid_evalue, mol_min_evalue
    print model_max_evalue, model.get_moments_of_inertia(vectors=True)[0][2]
    print "HERE"
    print model_moi[1][2]
    print model_max_evalue, model_moi[1][model_max_evalue]
    print mol_max_evalue, mol_moi[1][mol_max_evalue]


    #write('hex_model3_aligned.xyz',model)
    #write('hex_mol3_aligned.xyz',mol)
    this_model = model.copy()
    this_com = this_model.get_center_of_mass()
    this_model.positions -= np.tile(this_com, (len(this_model), 1))
    this_model.append(Atom('Cl',position=[0,0,0]))
    this_model.append(Atom('C',position=model.get_moments_of_inertia(vectors=True)[1][model_max_evalue]))
    this_model.append(Atom('S',position=model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]))
    this_model.append(Atom('O',position=model.get_moments_of_inertia(vectors=True)[1][model_mid_evalue]))
    write('hex_model.xyz',this_model)
    
    this_mol = mol.copy()
    this_com = this_mol.get_center_of_mass()
    this_mol.positions -= np.tile(this_com, (len(this_mol), 1))
    this_mol.append(Atom('Cl',position=[0,0,0]))
    this_mol.append(Atom('C',position=mol.get_moments_of_inertia(vectors=True)[1][mol_max_evalue]))
    this_mol.append(Atom('S',position=mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue]))
    this_mol.append(Atom('O',position=mol.get_moments_of_inertia(vectors=True)[1][mol_mid_evalue]))
    write('hex_mol.xyz',this_mol)
    
    ##Now align max to max
    write('hex_model3_prealigned.xyz',model+mol)
    #write('hex_mol3_prealigned.xyz',mol)
    moi_mol = Atoms()
    moi_mol.append(Atom('Cl',position=[0,0,0]))
    moi_mol.append(Atom('C',position=model.get_moments_of_inertia(vectors=True)[1][model_max_evalue]))
    moi_mol.append(Atom('S',position=model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]))
    moi_mol.append(Atom('O',position=model.get_moments_of_inertia(vectors=True)[1][model_mid_evalue]))
    mol.rotate(mol_moi[1][mol_max_evalue],model_moi[1][model_max_evalue],center=model_com)
    #moi_mol.append(Atom('O',position=model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]))
    #moi_mol.append(Atom('Ne',position=mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue]))
    #moi_mol.append(Atom('Cl',position=[0,0,0]))
    #moi_mol.append(Atom('Ar',position=mol_moi[1][mol_min_evalue]))
    write('hex_model3_semialigned.xyz',model+moi_mol)
    #write('hex_mol3_semialigned.xyz',mol)  ##UP TO HERE WORKS
    #Now we pick max distance dummy and align that, checking that vector is not parallel with max_moi
    #print model.get_moments_of_inertia(vectors=True)
    #print mol.get_moments_of_inertia(vectors=True)
    furthest_model_index = furthest_dummy(model)
    furthest_mol_index = furthest_dummy(mol)
    angle = get_general_angle(mol[furthest_mol_index].position,model[furthest_model_index].position,model_com)
    print "dummy - dummy angle =", angle
    mol.rotate(model_moi[1][model_max_evalue],angle,model_com)
    
    #Now because hexagon has symmetric moments, min and mid may be backwards

    #find angle
    #print "Angle is:"
    #print angle_2vectors(mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue],model.get_moments_of_inertia(vectors=True)[1][model_min_evalue])
    #mol.rotate(model_moi[1][model_max_evalue],-angle_2vectors(mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue],model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]),center=model_com)
#    mol.rotate(mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue],model.get_moments_of_inertia(vectors=True)[1][model_min_evalue],center=model_com)
    #mol.rotate(model.get_moments_of_inertia(vectors=True)[model_min_evalue],mol.get_moments_of_inertia(vectors=True)[mol_min_evalue],center=model_com)

    print"Final moments of inertia"
    print model.get_moments_of_inertia(vectors=True)
    print mol.get_moments_of_inertia(vectors=True)
    #Now because hexagon has symmetric moments, min and mid may be backwards
    #test
#    angle = get_general_angle(mol[mol.get_atom_indices('X')[0]].position,model[1].position,model_com) #index 0 is the COM
#    print "angle between mol model dummies is:", angle
   # print "final min/mid angle", angle_2vectors(mol.get_moments_of_inertia(vectors=True)[1][mol_mid_evalue],model.get_moments_of_inertia(vectors=True)[1][model_mid_evalue])

    

    write('hex_model3_aligned.xyz',model+mol)
#    write('hex_mol3_aligned.xyz',mol)  
    
    
    ##print 'numpy angle =            ',np.arccos(np.dot(mol_moi[1][mol_min_evalue]/np.linalg.norm(mol_moi[1][mol_min_evalue]),model_moi[1][model_min_evalue]/np.linalg.norm(model_moi[1][model_min_evalue])))


    ##Now align min to min, we'll assume that the max stays where it is, because perpendicular
    #mol.rotate(mol_moi[1][mol_min_evalue],model_moi[1][model_min_evalue],center=model_com)
    #write('hex_model3_aligned.xyz',model)
    #write('hex_mol3_aligned.xyz',mol)

#    ### old code below
#    model_dummies = model.get_atom_indices('X')
#    #Now we want to pair up each of the dummy atoms
#    model_midpoints = Atoms()
#    model_Q = model.get_atom_indices('Q')
#    model_midpoints.append(model[model_Q[0]])
#    model_Xpairs = {}
#    model_mask = np.zeros(len(model), dtype=bool )
#    for a1 in range(len(model_dummies)):
#        tmp_dist = {}
#        for a2 in range(len(model_dummies)):
#            if a1 != a2:
#                dist=model.get_distance(model_dummies[a1], model_dummies[a2])
#                tmp_dist[model_dummies[a2]] = dist
#        model_Xpairs[model_dummies[a1]] = min(tmp_dist, key=tmp_dist.get)  #This should be symmetric, but maybe check it
#        print model_Xpairs
#    for a1 in model_dummies:
#        if not model_mask[a1]:
#            new_midpoint = model[a1].position + (model[model_Xpairs[a1]].position - model[a1].position)/2
#            model_midpoints.append(Atom('X',position=new_midpoint))
#            model_mask[a1] = True
#            model_mask[model_Xpairs[a1]] = True
#    #Now the molecule
#    mol_dummies = mol.get_atom_indices('X')
#    #Now we want to pair up each of the dummy atoms
#    mol_midpoints = Atoms()
#    mol_midpoints.append(model[model_Q[0]])
#    mol_Xpairs = {}
#    mol_mask = np.zeros(len(mol), dtype=bool )
#    for a1 in range(len(mol_dummies)):
#        tmp_dist = {}
#        for a2 in range(len(mol_dummies)):
#            if a1 != a2:
#                dist=mol.get_distance(mol_dummies[a1], mol_dummies[a2])
#                tmp_dist[mol_dummies[a2]] = dist
#        mol_Xpairs[mol_dummies[a1]] = min(tmp_dist, key=tmp_dist.get)  #This should be symmetric, but maybe check it
#        print mol_Xpairs
#    for a1 in mol_dummies:
#        if not mol_mask[a1]:
#            new_midpoint = mol[a1].position + (mol[mol_Xpairs[a1]].position - mol[a1].position)/2
#            mol_midpoints.append(Atom('X',position=new_midpoint))
#            mol_mask[a1] = True
#            mol_mask[mol_Xpairs[a1]] = True
#
#    #write('hex_model3_prealigned.xyz',model)
#    #write('hex_mol3_prealigned.xyz',mol)
#    #Now we can start aligning. Yay!
#    angle = get_general_angle(mol_midpoints[1].position,model_midpoints[1].position,model_com) #index 0 is the COM
#    angle2 = get_general_angle(model_midpoints[1].position,mol_midpoints[1].position,model_com) #index 0 is the COM
#    print "First angle: ",angle
#    if angle < eps and angle2 < eps: #180deg
#        print "In Hexagon 180degree case"
#        v1=mol_midpoints.positions[1]-mol_midpoints.positions[2]  #doing this, because mol_com may not be in same plane as the three dummies
#        v2=mol_midpoints.positions[2]-mol_midpoints.positions[3]
#        v = np.cross(v1, v2)
#        mol.rotate(v,pi,center=model_com)
#    elif angle > eps: #1.0deg:
#        mol.rotate(mol_midpoints[1].position-model_com,model_midpoints[1].position-model_com,center=model_com)
#    #write('hex_model3_semialigned.xyz',model)
#    #write('hex_mol3_semialigned.xyz',mol)
#    #Now second rotation
#    dih = get_arbitrary_dihedral(mol_midpoints[2].position,model_com, model_midpoints[1].position, model_midpoints[2].position)
#    #write('hex_model3_aligned.xyz',model)
#    #write('hex_mol3_aligned.xyz',mol)
#    print "Hexagon dih = ", dih
#    if not isnan(dih) and dih > eps :#1.0deg
#        mol.rotate(model_midpoints[1].position-model_com,dih,center=model_com)
#    elif isnan(dih):
#        print "nan problem here"
#        #write('hex_model3_nanaligned.xyz',model)
#        #write('hex_mol3_nanaligned.xyz',mol)


    print "about to call TDT for hexagon case"
    this_min = transfer_dummy_tags_dist(mol,model)
    print "Min = ", this_min
#    mol.rotate(mol.get_moments_of_inertia(vectors=True)[1][mol_max_evalue],pi/2,center=model_com)
#    new_min = transfer_dummy_tags_dist(mol,model)
#    print "New Min = ", new_min
#    if new_min > this_min and new_min - this_min > 0.1: #then we were right the first time
#        print "reversing rotation!"
#        mol.rotate(mol.get_moments_of_inertia(vectors=True)[1][mol_max_evalue],-pi/2,center=model_com)
#        transfer_dummy_tags_dist(mol,model)

    #print "back from TDT"
    return

def align_cube(mol,model): #01/12/2014 MAA
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
        It is not assumed that all three dimensions are equal"""
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    eps=0.1
    #### Model ####
    # Now we need to determine the four pairs of opposite corners of the cube
    model_dummies = model.get_atom_indices('X')
    intra_model_distances=np.zeros((8,8))
    model_opp_corners={}
    for i1, d1 in enumerate(model_dummies):
        for i2, d2 in enumerate(model_dummies):
            intra_model_distances[i1,i2] = model.get_distance(d1,d2)
            intra_model_distances[i2,i1] = model.get_distance(d1,d2)
        model_opp_corners[d1] = model_dummies[intra_model_distances[:,i1].argmax()]    
    #print model_opp_corners     
    # take the 0th index and find out what's adjacent to it
    # the two closest distances are adjacent, but the third may not be
    me, model_adj_short_index, model_adj_mid_index = intra_model_distances[:,0].argsort()[:3]
    #print me, model_adj_short_index, model_adj_mid_index
    model_adj_short = model_dummies[model_adj_short_index] 
    model_adj_mid = model_dummies[model_adj_mid_index] 
    #print intra_model_distances[:,0] 
    #print "Short and mid to dummy 0 are:",model_adj_short, model_adj_mid
    # Now we find the midpoint of MAS and MAM, the (non-zero) corner that is nearest the midpoint is the last member of the face
    # We'll use this to align eventually
    model_faces = Atoms()
    model_midpoint_small = model[model_adj_short].position + (model[model_adj_mid].position - model[model_adj_short].position)/2.0
    model_faces.append(Atom('X',position=model_midpoint_small))
    these_distances = {}
    for i1,d1 in enumerate(model_dummies):
        if i1 != 0 and i1 != model_adj_short_index and i1 != model_adj_mid_index:
            print "d1 =",d1
            these_distances[d1] = get_intermolecular_distance(model_faces, model, 0, d1)
    model_fourth_index = min(these_distances, key=these_distances.get) #complete the first face
    model_adj_long= model_opp_corners[model_fourth_index]
    #print "Long to dummy 0 is:", model_adj_long
    model_midpoint_big = model[model_adj_mid].position + (model[model_adj_long].position - model[model_adj_mid].position)/2.0
    model_faces.append(Atom('X',position=model_midpoint_big))
    
    #write('cube_model_faces'+`mol[0].fragmentID`+'_prealigned.xyz',model_faces)
    #### Mol ####
    # Now we need to determine the four pairs of opposite corners of the cube
    mol_dummies = mol.get_atom_indices('X')
    intra_mol_distances=np.zeros((8,8))
    mol_opp_corners={}
    for i1, d1 in enumerate(mol_dummies):
        for i2, d2 in enumerate(mol_dummies):
            intra_mol_distances[i1,i2] = mol.get_distance(d1,d2)
            intra_mol_distances[i2,i1] = mol.get_distance(d1,d2)
        mol_opp_corners[d1] = mol_dummies[intra_mol_distances[:,i1].argmax()]    
    print mol_opp_corners
    # take the 0th index and find out what's adjacent to it
    # the two closest distances are adjacent, but the third may not be
    me, mol_adj_short_index, mol_adj_mid_index = intra_mol_distances[:,0].argsort()[:3]
    mol_adj_short = mol_dummies[mol_adj_short_index] 
    mol_adj_mid = mol_dummies[mol_adj_mid_index] 
    #print mol_adj_short, mol_adj_mid    
    # Now we find the midpoint of MAS and MAM, the (non-zero) corner that is nearest the midpoint is the last member of the face
    # We'll use this to align eventually
    mol_faces = Atoms()
    mol_midpoint_small = mol[mol_adj_short].position + (mol[mol_adj_mid].position - mol[mol_adj_short].position)/2.0
    mol_faces.append(Atom('X',position=mol_midpoint_small))
    these_distances = {}
    for i1,d1 in enumerate(mol_dummies):
        if i1 != 0 and i1 != mol_adj_short_index and i1 != mol_adj_mid_index:
            these_distances[d1] = get_intermolecular_distance(mol_faces, mol, 0, d1)
    mol_fourth_index = min(these_distances, key=these_distances.get) #complete the first face
    mol_adj_long= mol_opp_corners[mol_fourth_index]
    mol_midpoint_big = mol[mol_adj_mid].position + (mol[mol_adj_long].position - mol[mol_adj_mid].position)/2.0
    mol_faces.append(Atom('X',position=mol_midpoint_big))
    # Now we finally align, biggest face first
    write('cube_model'+`mol[0].fragmentID`+'_prealigned.xyz',model)
    write('cube_mol'+`mol[0].fragmentID`+'_prealigned.xyz',mol)
    write('cube_mol_faces'+`mol[0].fragmentID`+'_prealigned.xyz',mol_faces)
    angle = get_general_angle(mol_midpoint_big,model_midpoint_big,model_com)
    fixed_axis = model_midpoint_big-model_com
    print "First angle = ",angle
    if angle > 0.02:#1.0deg:
        print "Rotating by ",angle
        mol.rotate(mol_midpoint_big-model_com,model_midpoint_big-model_com,center=model_com)
    write('cube_model'+`mol[0].fragmentID`+'_semialigned.xyz',model)
    write('cube_mol'+`mol[0].fragmentID`+'_semialigned.xyz',mol)
    #Now update the position of mol_midpoint_small
    mol_midpoint_small = mol[mol_adj_short].position + (mol[mol_adj_mid].position - mol[mol_adj_short].position)/2.0
    #Now we can do the second rotation
    angle = get_arbitrary_dihedral(mol_midpoint_small,model_com,model_midpoint_big,model_midpoint_small)
    print "2nd angle =", angle
    if angle > 0.02 and abs(angle -  pi) > eps:
        print "Rotating by ",angle
        mol.rotate(fixed_axis,angle,center=model_com)

    write('cube_model'+`mol[0].fragmentID`+'_aligned.xyz',model)
    write('cube_mol'+`mol[0].fragmentID`+'_aligned.xyz',mol)

    transfer_dummy_tags_dist(mol,model)
    return


def align_gyrobifastigium(mol,model): #J26
    """Shape is a tetrahedron intersected by a square
       Moves COM_mol to COM_model and then aligns major inertial axis,
       then rotates the molecule to align the dummies."""
    eps = 0.02 #on agles, about 1 deg
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    ####
    print "model MoI:"
    print model.get_masses()
    #need to alter our dummy masses here
    new_model_masses = []
    for m in model:
        if m.symbol == "Q":
            new_model_masses.append(1000.0)
        elif m.symbol == "X":
            new_model_masses.append(10.0)
        else:
            new_model_masses.append(None)
    model.set_masses(new_model_masses)
    print model.get_masses()
    model_moi = model.get_moments_of_inertia(vectors=True)
    print model.get_moments_of_inertia(vectors=True)
    print model.get_moments_of_inertia(vectors=True)[0]
    #need to alter our dummy masses here
    new_mol_masses = []
    for m in mol:
        if m.symbol == "Q":
             new_mol_masses.append(1000.0)
        elif m.symbol == "X":
             new_mol_masses.append(100.0)
        else:
             new_mol_masses.append(0.0)
    mol.set_masses(new_mol_masses)
    print "mol MoI:"
    print mol.get_moments_of_inertia(vectors=True)
    mol_moi = mol.get_moments_of_inertia(vectors=True)
    ###
    #now determine position of max and min eigenvalues
    model_max_evalue = np.argmax(model.get_moments_of_inertia(vectors=True)[0])
    model_min_evalue = np.argmin(model.get_moments_of_inertia(vectors=True)[0])
    mol_max_evalue = np.argmax(mol.get_moments_of_inertia(vectors=True)[0])
    mol_min_evalue = np.argmin(mol.get_moments_of_inertia(vectors=True)[0])
    model_mid_evalue = 3 - (model_max_evalue + model_min_evalue)
    mol_mid_evalue = 3 - (mol_max_evalue + mol_min_evalue)
    print model_max_evalue, model_mid_evalue, model_min_evalue, mol_max_evalue, mol_mid_evalue, mol_min_evalue
    print model_max_evalue, model.get_moments_of_inertia(vectors=True)[0][2]
    print "HERE"
    print model_moi[1][2]
    print model_max_evalue, model_moi[1][model_max_evalue]
    print mol_max_evalue, mol_moi[1][mol_max_evalue]


    #write('J26_model3_aligned.xyz',model)
    #write('J26_mol3_aligned.xyz',mol)
    this_model = model.copy()
    this_com = this_model.get_center_of_mass()
    this_model.positions -= np.tile(this_com, (len(this_model), 1))
    this_model.append(Atom('Cl',position=[0,0,0]))
    this_model.append(Atom('C',position=model.get_moments_of_inertia(vectors=True)[1][model_max_evalue]))
    this_model.append(Atom('S',position=model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]))
    this_model.append(Atom('O',position=model.get_moments_of_inertia(vectors=True)[1][model_mid_evalue]))
    write('J26_model.xyz',this_model)
    
    this_mol = mol.copy()
    this_com = this_mol.get_center_of_mass()
    this_mol.positions -= np.tile(this_com, (len(this_mol), 1))
    this_mol.append(Atom('Cl',position=[0,0,0]))
    this_mol.append(Atom('C',position=mol.get_moments_of_inertia(vectors=True)[1][mol_max_evalue]))
    this_mol.append(Atom('S',position=mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue]))
    this_mol.append(Atom('O',position=mol.get_moments_of_inertia(vectors=True)[1][mol_mid_evalue]))
    write('J26_mol.xyz',this_mol)
    
    ##Now align max to max
    write('J26_model3_prealigned.xyz',model+mol)
    #write('J26_mol3_prealigned.xyz',mol)
    moi_mol = Atoms()
    moi_mol.append(Atom('Cl',position=[0,0,0]))
    moi_mol.append(Atom('C',position=model.get_moments_of_inertia(vectors=True)[1][model_max_evalue]))
    moi_mol.append(Atom('S',position=model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]))
    moi_mol.append(Atom('O',position=model.get_moments_of_inertia(vectors=True)[1][model_mid_evalue]))
    mol.rotate(mol_moi[1][mol_max_evalue],model_moi[1][model_max_evalue],center=model_com)
    #moi_mol.append(Atom('O',position=model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]))
    
    #Now second rotation
    write('hex_model3_semialigned.xyz',model+moi_mol)
    #write('hex_mol3_semialigned.xyz',mol)  ##UP TO HERE WORKS
    #Now we pick max distance dummy and align that, checking that vector is not parallel with max_moi
    #print model.get_moments_of_inertia(vectors=True)
    #print mol.get_moments_of_inertia(vectors=True)
    furthest_model_index = furthest_dummy(model)
    furthest_mol_index = furthest_dummy(mol)
    angle = get_general_angle(mol[furthest_mol_index].position,model[furthest_model_index].position,model_com)
    print "dummy - dummy angle =", angle
    mol.rotate(model_moi[1][model_max_evalue],angle,model_com)

    print"Final moments of inertia"
    print model.get_moments_of_inertia(vectors=True)
    print mol.get_moments_of_inertia(vectors=True)

    #transfer_dummy_tags(mol,model)
    transfer_dummy_tags_dist(mol,model)
    #print "back from TDT"
    #print mol.get_tags()
    return    


def align_mfu4(mol,model): #completely untested 11/02/2014 MAA... 13/02/2014 Seems to work :-)
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
    We find the midpoint of each pair of tags and then align like an octahedron.""" #The reason we don't align on an octahedron model is tags
    eps = 0.1
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    model_dummy_tags={}
    model_tag_indices={}
    for a in model:
        if a.tag:
            model_dummy_tags[a.index]=a.tag
            model_tag_indices[a.tag]=a.index
    model_dummies = model.get_atom_indices('X')
    #Now we want to pair up each of the dummy atoms
    model_midpoints = Atoms()
    model_Q = model.get_atom_indices('Q')
    model_midpoints.append(model[model_Q[0]])
    model_Xpairs = {}
    model_mask = np.zeros(len(model), dtype=bool )
    for a1 in range(len(model_dummies)):
        tmp_dist = {}
        for a2 in range(len(model_dummies)):
            if a1 != a2:
                dist=model.get_distance(model_dummies[a1], model_dummies[a2])
                tmp_dist[model_dummies[a2]] = dist
        model_Xpairs[model_dummies[a1]] = min(tmp_dist, key=tmp_dist.get)  #This should be symmetric, but maybe check it
        print model_Xpairs
    for a1 in model_dummies:
        if not model_mask[a1]:
            new_midpoint = model[a1].position + (model[model_Xpairs[a1]].position - model[a1].position)/2
            model_midpoints.append(Atom('X',position=new_midpoint))
            model_mask[a1] = True
            model_mask[model_Xpairs[a1]] = True
    #Now the molecule
    mol_dummies = mol.get_atom_indices('X')
    #Now we want to pair up each of the dummy atoms
    mol_midpoints = Atoms()
    mol_midpoints.append(model[model_Q[0]])
    mol_Xpairs = {}
    mol_mask = np.zeros(len(mol), dtype=bool )
    for a1 in range(len(mol_dummies)):
        tmp_dist = {}
        for a2 in range(len(mol_dummies)):
            if a1 != a2:
                dist=mol.get_distance(mol_dummies[a1], mol_dummies[a2])
                tmp_dist[mol_dummies[a2]] = dist
        mol_Xpairs[mol_dummies[a1]] = min(tmp_dist, key=tmp_dist.get)  #This should be symmetric, but maybe check it
        print mol_Xpairs
    for a1 in mol_dummies:
        if not mol_mask[a1]:
            new_midpoint = mol[a1].position + (mol[mol_Xpairs[a1]].position - mol[a1].position)/2
            mol_midpoints.append(Atom('X',position=new_midpoint))
            mol_mask[a1] = True
            mol_mask[mol_Xpairs[a1]] = True
            
    #Now we can start aligning. Yay!
    #write('model4_nonaligned.xyz',model)
    #write('mol4_nonaligned.xyz',mol)
    #write('model4_midpoints.xyz',model_midpoints)
    #write('mol4_midpoints.xyz',mol_midpoints)
    #For lack of anything more intelligent, we'll align on the first midpoint
    angle = get_general_angle(mol_midpoints[1].position,model_midpoints[1].position,model_com) #index 0 is the COM
    print "Angle = ", angle
    if angle > 0.02 and abs(angle - pi) >0.02:#1.0:
        mol.rotate(mol_midpoints[1].position-model_com,model_midpoints[1].position-model_com,center='COM')
    fixed_axis = mol_midpoints[1].position-model_com
    write('model4_semialigned.xyz',model)
    write('mol4_semialigned.xyz',mol)
    #Second alignment. An angle should work, but we'll use a dihedral in case
    #We can pick any midpoint, for both the model and mol, except the one that is furthest away
    if model_midpoints.get_distance(1,2) < model_midpoints.get_distance(1,3):
        model_X = 2
    else:
        model_X = 3
    if mol_midpoints.get_distance(1,2) < mol_midpoints.get_distance(1,3):
        mol_X = 2
    else:
        mol_X = 3

    dih=get_arbitrary_dihedral(mol_midpoints[mol_X].position,model_com, model_midpoints[1].position, model_midpoints[model_X].position)
    print "Dih = ",dih*180/pi
    mol.rotate(fixed_axis,dih,center='COM')
    #any extra rotation is defined as being around the D3d axis
    if 'rotate' in mol.info:
        rot_angle = mol.info['rotate'] * pi / 180
        mol.rotate(fixed_axis,rot_angle,center=model_com)

    write('model4_aligned.xyz',model)
    write('mol4_aligned.xyz',mol)
    #transfer the dummy tags
    try:
        transfer_dummy_tags_dist(mol,model)
    except RuntimeError: #We can be 90 deg off
        print "Rotating by 90 deg, because of misalignment"
        mol.rotate(fixed_axis,90 * pi / 180,center='COM')
        transfer_dummy_tags_dist(mol,model)

    return

def align_mil53(mol,model):
    """Aligns the heavy atom and then
    rotates appropriately to align the other dummies."""
    eps = 0.02

    model_heavy_atoms = model.get_atom_indices('Q')
    #Now we need to get the metal atoms of the connector
    mol_heavy_atoms = [item for item in range(len(mol.get_atomic_numbers())) if mol[item].number >10]
    #translate
    mol.translate(model[model_heavy_atoms[0]].position - mol[mol_heavy_atoms[0]].position) #should check length of heavy_atoms, but...
    model_dummies = model.get_atom_indices('X')
    #anchor is the midpoints of the dummies
    #Now we need to align the true dummies
    #model_dummies = model.get_atom_indices('X')
    #First to find them
    #We'll rely on them being typed - i.e. an atom type of C_R #otherwise we could find them as close to mol_furthest_Q
    mol_true_dummies = [atom.index for atom in mol if atom.symbol == 'X' and atom.mmtype == 'C_R']
    #Now there are two ways to align, only one is correct
    model_midpoint = model[model_dummies[0]].position + (model[model_dummies[1]].position - model[model_dummies[0]].position)/2
    mol_midpoint = mol[mol_true_dummies[0]].position + (mol[mol_true_dummies[1]].position - mol[mol_true_dummies[0]].position)/2
    #Now, keeping the heavy atoms fixed, align the heavy-midpoint axes
    angle = get_general_angle(model_midpoint,model[model_heavy_atoms[0]].position,mol_midpoint)
    print "Align MIL, first angle =", angle
    if angle > eps:
        mol.rotate(mol_midpoint - mol[mol_heavy_atoms[0]].position, model_midpoint - model[model_heavy_atoms[0]].position, center=mol[mol_heavy_atoms[0]].position)
    write('model53_semialigned.xyz',model)
    write('mol53_semialigned.xyz',mol)
    #Recalc 
    mol_midpoint = mol[mol_true_dummies[0]].position + (mol[mol_true_dummies[1]].position - mol[mol_true_dummies[0]].position)/2
    #Now use COM. Relies on the model providing the second M/Q atom
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    #now align
    ##print "working out dihedral:"
    ##print mol_com
    ##print mol[mol_heavy_atoms[0]].position
    ##print mol_midpoint
    ##print model_com
    dih = get_arbitrary_dihedral(mol_com, mol[mol_heavy_atoms[0]].position, mol_midpoint, model_com)
    print "MIL53 dih =", dih
    if dih > eps:
        mol.rotate(model_midpoint - model[model_heavy_atoms[0]].position,dih,center=mol[mol_heavy_atoms[0]].position)
    write('model53_aligned.xyz',model)
    write('mol53_aligned.xyz',mol)
#    print "----------------------------"
#    for blah in model:
#        print blah.symbol, blah.position
#    model_com = model.get_center_of_mass()
#    print model_com
#    print "----------------------------"
#    for blah in mol:
#        print blah.symbol, blah.position
#    mol_com = mol.get_center_of_mass()
#    print mol_com
    
    #angle = get_general_angle
    #Now set up the second rotation
    #transfer the dummy tags
    #transfer_dummy_tags_dist(mol,model)
    transfer_dummy_tags_mil53(mol,model)

    for atom in mol:
        if atom.symbol == 'X':
            print atom.index, atom.tag
    return


def align_cpo27(mol,model):
    """CPO-27 is another special 1D rod framework.
       We first translate the metal atom, then rotate to match the non-CO2 oxygen
       (marked as a second Q), finally we align the CO2 (marked as X).
       This relies on attaching MMtypes to the relevant dummies and ghosts
       Extra dummies carry tags for connectivity."""

    eps = 0.1    
    #### Model ####
    model_heavy_atoms = model.get_atom_indices('Q')
    model_com_index = np.where(model.get_mmtypes() == 'M')[0][0]
    model_oxy_index = np.where(model.get_mmtypes() == 'O')[0][0]
    model_co2_index = np.where(model.get_mmtypes() == 'CO2')[0][0]
    model_com = model[model_com_index].position
    model_oxy = model[model_oxy_index].position
    model_co2 = model[model_co2_index].position
    #print "ACPO:", model_com, model_oxy, model_co2
    #### Mol ####
    mol_com_index = np.where(np.logical_and(mol.get_atomic_numbers() >10, mol.get_atomic_numbers() < 100))[0][0] #first heavy atom, excluding the Bq (ghost)
    mol_oxy_index = np.where(mol.get_mmtypes() == 'O_3')[0][0] #unique O
    # For the mol co2, we have to decide between two O_R-tagged O. We want the closest one, and while we could assume, we won't
    mol_co2_o = np.where(mol.get_mmtypes() == 'O_2')
    #print "ACPO-2:", mol_com, mol_oxy, mol_co2_o
    mol_o_distances = [mol.get_distance(mol_com_index,o) for o in mol_co2_o]
    mol_co2_index = mol_co2_o[0][np.argmin(mol_o_distances)]
    mol_com = mol[mol_com_index].position
    mol_oxy = mol[mol_oxy_index].position
    mol_co2 = mol[mol_co2_index].position
    #print "ACPO-3", mol_o_distances, mol_co2
    # Translate
    mol.translate(model_com - mol_com)
    # First rotation
    angle = get_general_angle(mol_oxy,model_com,model_oxy)
    print "First angle: ",angle
    if angle > 0.02:#1.0deg:
        print "Rotating by ",angle
        mol.rotate(mol_oxy-mol_com, model_oxy-model_com,model_com)
    fixed_axis = model_oxy-model_com
    # Second rotation
    angle = get_arbitrary_dihedral(model_co2,model_oxy,model_com,mol_co2)
    print "2nd angle =", angle
    if angle > 0.02: #and abs(angle -  pi) > eps:
        print "Rotating by ",angle
        mol.rotate(fixed_axis, angle,center=model_com)

    transfer_dummy_tags_cpo27(mol,model)
        

    write('cpo27_model'+`mol[0].fragmentID`+'_aligned.xyz',model)
    write('cpo27_mol'+`mol[0].fragmentID`+'_aligned.xyz',mol)

    return

#def align_mil53_dimer(mol,model): #10/04/2014 incomplete
#    """Aligns the heavy atoms (there are two) and then 
#    rotates appropriately to align the other dummies."""
#    eps = 0.02
#    
#    model_com = model.get_center_of_mass()
#    mol_com = mol.get_center_of_mass()
#    mol.translate(model_com - mol_com)
#    write('model53_translated.xyz',model)
#    write('mol53_translated.xyz',mol)
#    model_heavy_atoms = model.get_atom_indices('Q')
#    #Now we need to get the metal atoms of the connector
#    mol_heavy_atoms = [item for item in range(len(mol.get_atomic_numbers())) if mol[item].number >10]
#    print model_heavy_atoms
#    print mol_heavy_atoms
#    #Now find the metal atom closest to the COM
#    #model
#    if np.linalg.norm(model_heavy_atoms[0] - model_com) < np.linalg.norm(model_heavy_atoms[1] - model_com):
#        model_nearest_Q = model_heavy_atoms[0]
#        model_furthest_Q = model_heavy_atoms[1]
#    else:
#        model_nearest_Q = model_heavy_atoms[1]
#        model_furthest_Q = model_heavy_atoms[0]
#    #mol
#    if np.linalg.norm(mol_heavy_atoms[0] - mol_com) < np.linalg.norm(mol_heavy_atoms[1] - mol_com):
#        mol_nearest_Q = mol_heavy_atoms[0]
#        mol_furthest_Q = mol_heavy_atoms[1]
#    else:
#        mol_nearest_Q = mol_heavy_atoms[1]
#        mol_furthest_Q = mol_heavy_atoms[0]
#    #Now re-translate and align 
#    #mol.translate(model[model_nearest_Q].position - mol[mol_nearest_Q].position)
#    write('model53_nonaligned.xyz',model)
#    write('mol53_nonaligned.xyz',mol)
#    angle = get_general_angle(mol[mol_furthest_Q].position,model[model_furthest_Q].position,model[model_nearest_Q].position)
#    angle2 = get_general_angle(model[model_furthest_Q].position,mol[mol_furthest_Q].position,model[model_nearest_Q].position)
#    if angle < eps and angle2 < eps: #180deg
#        pass
#    elif angle > 0.02:
#        mol.rotate(mol[mol_furthest_Q].position - model[model_nearest_Q].position,
#                model[model_furthest_Q].position - model[model_nearest_Q].position, center=model[model_nearest_Q].position)
#    #check    
#    write('model53_semialigned.xyz',model)
#    write('mol53_semialigned.xyz',mol)
#    #Now we need to align the true dummies
#    model_dummies = model.get_atom_indices('X')
#    #First to find them
#    #We'll rely on them being typed - i.e. an atom type of C_R #otherwise we could find them as close to mol_furthest_Q
#    mol_true_dummies = [atom.index for atom in mol if atom.symbol == 'X' and atom.mmtype == 'C_R']
#    #print mol_true_dummies
#    #Find the closest dummies to the terminal M
#    intra_model_distances = {}
#    for dindex in model_dummies:
#        this_dist = model.get_distance(model_furthest_Q,dindex)
#        intra_model_distances[dindex] = this_dist
#    sorted_ImodelD = sorted(intra_model_distances, key=intra_model_distances.get)
#    #mol
#    intra_mol_distances = {}
#    for dindex in mol_true_dummies:
#        this_dist = mol.get_distance(mol_furthest_Q,dindex)
#        intra_mol_distances[dindex] = this_dist
#    sorted_ImolD = sorted(intra_mol_distances, key=intra_mol_distances.get)
#    #Now we align on the first of both mol and model, see if if works and then try first to second alignment
#    dih = get_arbitrary_dihedral(mol[sorted_ImolD[0]].position,model[model_furthest_Q].position,model[model_nearest_Q].position, model[sorted_ImodelD[0]].position)
#    if dih > 0.02:
#        mol.rotate(model[model_furthest_Q].position - model[model_nearest_Q].position,dih,model[model_nearest_Q].position)
#
#
#    write('model53_aligned.xyz',model)
#    write('mol53_aligned.xyz',mol)
#    #print mol_com
#
#    
#    #Now first slign it with the heavy-heavy axis
#
#    transfer_dummy_tags_dist(mol,model)
#    return

def align_cuboctahedron(mol,model): #20/03/2014 Tested 30/03/2014
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies"""
    eps = 0.1
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    #Grab the tags on the model and sort them asciibetically. We'll use a dict.
    #model_dummy_tags={}
    #model_tag_indices={}
    #for a in model:
    #    if a.tag:
    #        model_dummy_tags[a.index]=a.tag
    #        model_tag_indices[a.tag]=a.index
    model_dummies = model.get_atom_indices('X')

    #In the ideal Fm-3m (225) symmetry, from one reference endpoint toother endpoints via the COM, there will be 1 180 deg angle, 1 0 deg angle (me),
    #4 60 deg angles, 4 120 deg angles and 2 90 deg angles.
    intra_model_angles = {}
    for d1 in model_dummies:
        this_angle = get_general_angle(model[model_dummies[0]].position, model_com, model[d1].position)
        if abs(this_angle -  pi/2) < eps:
            model_perp_index = d1
            break
    #Now mol
    mol_dummies = mol.get_atom_indices('X')
    intra_mol_angles = {}
    for d1 in mol_dummies:
        this_angle = get_general_angle(mol[mol_dummies[0]].position, model_com, mol[d1].position)
        print d1, this_angle
        if abs(this_angle -  pi/2) < eps:
            mol_perp_index = d1
            break

    #Now first alignment
    angle = get_general_angle(mol.positions[mol_dummies[0]],model_com,model.positions[model_dummies[0]])
    print "First angle: ",angle
    if angle > eps:#1.0:
        mol.rotate(mol.positions[mol_dummies[0]]-model_com,model.positions[model_dummies[0]]-model_com,center=model_com)

    #write('model4_semialigned.xyz',model)
    #write('mol4_semialigned.xyz',mol)
    #Second alignment can be done straight away
    dih=get_arbitrary_dihedral(mol[mol_perp_index].position,model[model_dummies[0]].position,model_com,model[model_perp_index].position)
    print "Second angle: ",angle
    if dih > eps:#1.0:
        mol.rotate(model[model_dummies[0]].position-model_com,-dih,center=model_com) #use the model centroid as the centroid is not updated
    #write('model4_aligned.xyz',model)
    #write('mol4_aligned.xyz',mol)

    transfer_dummy_tags_dist(mol,model)

    return

def align_elongated_triangular_orthobicupola(mol,model):
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
       18 vertex figure, D3h symmetry: triangle, hexagon, hexagon, triangle. """ 
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    eps=0.1 
    #### Model ####
    model_dummies = model.get_atom_indices('X')
    #### Mol ####
    mol_dummies = mol.get_atom_indices('X')

    # Now we have to find the triangles. We want the top and bottom planes, but there are six other triangles to confuse us
    # We look for the most equilateral triangle
    #### Model ####
    model_comb_distances = {}
    
    for (i1,i2,i3) in combinations(model_dummies, 3):
            these_dists = np.array([model.get_distance(i1,i2), model.get_distance(i1,i3), model.get_distance(i2,i3)])
            minus_mean = np.subtract(these_dists,np.mean(these_dists))
            #print "Here", i1,i2,i3, " : ",  these_dists, np.mean(these_dists), "|",minus_mean 
            if np.allclose(minus_mean,np.zeros(3), atol=1e-02):
                #print "Model triangle is", i1,i2,i3
                model_comb_distances[(i1,i2,i3)] = np.mean(these_dists)

    #print "Model_comb_distances:"
    #print model_comb_distances
    sorted_model_triangles = sorted(model_comb_distances, key=model_comb_distances.get)
    model_top_triangle = sorted_model_triangles[0]
    model_bottom_triangle = sorted_model_triangles[1]
    print model_top_triangle, model_comb_distances[model_top_triangle]
    print model_bottom_triangle, model_comb_distances[model_bottom_triangle]
    model_top_face = Atoms('X3',positions=[model[model_top_triangle[0]].position,model[model_top_triangle[1]].position,model[model_top_triangle[2]].position])
    model_top_centroid = model_top_face.get_center_of_dummies()

    #### Mol ####
    mol_comb_distances = {}
    
    for (i1,i2,i3) in combinations(mol_dummies, 3):
            these_dists = np.array([mol.get_distance(i1,i2), mol.get_distance(i1,i3), mol.get_distance(i2,i3)])
            minus_mean = np.subtract(these_dists,np.mean(these_dists))
            print "Here", i1,i2,i3, " : ",  these_dists, np.mean(these_dists), "|",minus_mean 
            if np.allclose(minus_mean,np.zeros(3), atol=1e-02):
                print "Mol triangle is", i1,i2,i3
                mol_comb_distances[(i1,i2,i3)] = np.mean(these_dists)

    #print "Mol_comb_distances:"
    #print mol_comb_distances
    sorted_mol_triangles = sorted(mol_comb_distances, key=mol_comb_distances.get)
    mol_top_triangle = sorted_mol_triangles[0]
    mol_bottom_triangle = sorted_mol_triangles[1]
    print mol_top_triangle, mol_comb_distances[mol_top_triangle]
    print mol_bottom_triangle, mol_comb_distances[mol_bottom_triangle]
    mol_top_face = Atoms('X3',positions=[mol[mol_top_triangle[0]].position,mol[mol_top_triangle[1]].position,mol[mol_top_triangle[2]].position])
    mol_top_centroid = mol_top_face.get_center_of_dummies()

    #### Align 1 ####
    angle = get_general_angle(mol_top_centroid,model_com,model_top_centroid)
    fixed_axis = model_top_centroid-model_com
    tmp = Atoms('X3',positions=[mol_top_centroid,model_top_centroid,model_com])
    write('eto_tmp1.xyz',tmp)
    print "First angle = ",angle
    if angle > 0.02:#1.0deg:
        print "Rotating by ",angle
        mol.rotate(mol_top_centroid-model_com,model_top_centroid-model_com,center=model_com)

    write('eto_model'+`mol[0].fragmentID`+'_semialigned.xyz',model)
    write('eto_mol'+`mol[0].fragmentID`+'_semialigned.xyz',mol)
    #### Align 2 ####
    # Still using the top triangle, align first index to first index (D3h, this works )
    angle = get_arbitrary_dihedral(model[model_top_triangle[0]].position,model_top_centroid,model_com,mol[mol_top_triangle[0]].position)
    tmp = Atoms('X4',positions=[model[model_top_triangle[0]].position,model_top_centroid,model_com,mol[mol_top_triangle[0]].position])
    write('eto_tmp2.xyz',tmp)
    print "2nd angle =", angle
    if angle > 0.02 and abs(angle -  pi) > eps:
        print "Rotating by ",angle
        mol.rotate(fixed_axis, angle,center=model_com)

    write('eto_model'+`mol[0].fragmentID`+'_aligned.xyz',model)
    write('eto_mol'+`mol[0].fragmentID`+'_aligned.xyz',mol)
    transfer_dummy_tags_dist(mol,model)

    return


def align_rhombicuboctahedron(mol,model): #01/12/2014 MAA
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
       This is a small rhombicuboctahedron, with 8 triangle and 16 square faces"""
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    eps=0.1
    #### Model ####
    model_dummies = model.get_atom_indices('X')
    #### Mol ####
    mol_dummies = mol.get_atom_indices('X')

    #write('rhombi_model'+`mol[0].fragmentID`+'_prealigned.xyz',model)
    #write('rhombi_mol'+`mol[0].fragmentID`+'_prealigned.xyz',mol)
    # Now align the first dummy
    angle = get_general_angle(mol[mol_dummies[0]].position,model[model_dummies[0]].position,model_com)
    fixed_axis = model[model_dummies[0]].position-model_com
    print "First angle = ",angle
    if angle > 0.02:#1.0deg:
        print "Rotating by ",angle
        mol.rotate(mol[mol_dummies[0]].position-model_com,model[model_dummies[0]].position-model_com,center=model_com)
    #write('rhombi_model'+`mol[0].fragmentID`+'_semialigned.xyz',model)
    #write('rhombi_mol'+`mol[0].fragmentID`+'_semialigned.xyz',mol)
    # Now, each vertex joins one triangle and three square faces.
    # So we'll find the four nearest vertices and then find the pair that are the closest
    # The pair that are closest are the triangle, so we'll use their midpoint to align on
    #### Model ####
    intra_model_distances = {}
    for d2 in model_dummies:
        intra_model_distances[d2] = model.get_distance(model_dummies[0],d2)
    sorted_model_DD = sorted(intra_model_distances, key=intra_model_distances.get)
    model_nearest_indices = sorted_model_DD[1:5]
    closest_model_distances = {}
    for (i1,i2) in combinations(model_nearest_indices, 2):
        closest_model_distances[(i1,i2)] = model.get_distance(i1,i2)
    #print closest_model_distances
    model_triangle_pair = min(closest_model_distances, key=closest_model_distances.get)    
    #print model_triangle_pair
    #print "Model sorted indices:",sorted_model_DD 
    #print "Model nearest indices:",model_nearest_indices
    model_midpoint = model[model_triangle_pair[0]].position + (model[model_triangle_pair[1]].position - model[model_triangle_pair[0]].position)/2.0
    #### Mol ####
    intra_mol_distances = {}
    for d2 in mol_dummies:
        intra_mol_distances[d2] = mol.get_distance(mol_dummies[0],d2)
    sorted_mol_DD = sorted(intra_mol_distances, key=intra_mol_distances.get)
    mol_nearest_indices = sorted_mol_DD[1:5]
    closest_mol_distances = {}
    for (i1,i2) in combinations(mol_nearest_indices, 2):
        closest_mol_distances[(i1,i2)] = mol.get_distance(i1,i2)
    #print closest_mol_distances
    mol_triangle_pair = min(closest_mol_distances, key=closest_mol_distances.get)    
    #print mol_triangle_pair
    mol_midpoint = mol[mol_triangle_pair[0]].position + (mol[mol_triangle_pair[1]].position - mol[mol_triangle_pair[0]].position)/2.0
    #print "Mol sorted indices:",sorted_mol_DD 
    #print "Mol nearest indices:",mol_nearest_indices 

    # Now second alignment
    angle = get_arbitrary_dihedral(mol_midpoint, model[model_dummies[0]].position, model_com, model_midpoint)
    print "2nd angle =", angle
    if angle > 0.02 and abs(angle -  pi) > eps:
        print "Rotating by ",angle
        mol.rotate(fixed_axis,-angle,center=model_com)

    #write('rhombi_model'+`mol[0].fragmentID`+'_aligned.xyz',model)
    #write('rhombi_mol'+`mol[0].fragmentID`+'_aligned.xyz',mol)

    transfer_dummy_tags_dist(mol,model)

    return

def transfer_dummy_tags_linear(mol,model):
    """For linear guys we use the centre-of-dummies as the COM doesn't have to line up"""
    mol_dummies = mol.get_atom_indices('X')
    model_dummies = model.get_atom_indices('X')
    com=mol.get_center_of_dummies()
    eps=0.20
    for a in model_dummies:
        for b in mol_dummies:
            print com,model[a].position,mol[b].position
            angle=get_general_angle(model[a].position,com,mol[b].position)
            print a,b,angle, model[a].tag
            if angle < eps:  #angle is always positive
                #mol[b].tag = ''.join(model[a].tag)
                mol[b].tag = model[a].tag
                print "TDT assign:",a,b, angle, pi, angle-pi, angle, model[a].tag
                break
                #print a,b,angle, model[a].tag

def transfer_dummy_tags(mol,model): 
    mol_dummies = mol.get_atom_indices('X')
    model_dummies = model.get_atom_indices('X')
    com=mol.get_center_of_mass()
    eps=0.05 #in radians = 2.86 deg
    for a in model_dummies:
        for b in mol_dummies:
            #angle=get_general_angle(com,model[a].position,mol[b].position)
            angle=get_general_angle(model[a].position,com,mol[b].position)
            #angle=get_general_angle(com,mol[b].position,model[a].position)
            print a,b, angle
            #if angle >pi - eps:  #angle is always positive
            if angle < eps:  #angle is always positive
                mol[b].tag = model[a].tag
                print "TDT assign:",a,b, angle, pi, angle-pi, angle, model[a].tag
                break
            #elif angle > pi :
            #    print "Angle > pi"
            #    mol[b].tag = model[a].tag
            #    break
    #Need to add in a test to make sure everything is assigned
    return

#def transfer_dummy_tags_dist(mol,model): ##This assigns the closest mol dummy to each model dummy, fails sometimes
#    mol_dummies = mol.get_atom_indices('X')
#    model_dummies = model.get_atom_indices('X')
#    com=mol.get_center_of_mass()
#    write('tdtd-mol.xyz',mol)
#    write('tdtd-model.xyz',model)
#    #Now we set up a dictionary to match dummy to dummy
#    model_to_mol={}
#    for a in model_dummies:
#        these_distances = {}
#        for b in mol_dummies:
#            this_dist = get_intermolecular_distance(model, mol, a, b)
#            these_distances[b] = this_dist
#        print "TDTD: ",these_distances
#        if min(these_distances, key=these_distances.get) not in model_to_mol.values():
#            model_to_mol[a] = min(these_distances, key=these_distances.get)
#        else:
#            model_to_mol[a] = min(these_distances, key=these_distances.get)
#            print model_to_mol
#            raise RuntimeError('Transferring dummy tags based on distance criteria. Something assigned twice.')
#
#    assigned = 0
#    for a_mod,a_mol in model_to_mol.iteritems():
#        mol[a_mol].tag = model[a_mod].tag
#        assigned += 1
#        print "TDT-distance  assign:",a_mod,a_mol,model[a_mod].tag
# 
#    if assigned != len(model_dummies):
#        raise RuntimeError('Not all tags transferred!')
#
#    return

def transfer_dummy_tags_dist(mol,model):    #This assigns the closest model dummy to each mol dummy
    mol_dummies = mol.get_atom_indices('X')
    model_dummies = model.get_atom_indices('X')
    com=mol.get_center_of_mass()
    write('tdtd-mol.xyz',mol)
    write('tdtd-model.xyz',model)
    #Now we set up a dictionary to match dummy to dummy
    mol_to_model={}
    dist_sum = 0 
    for a in mol_dummies:
        these_distances = {}
        min_dist = 1000
        for b in model_dummies:
            this_dist = get_intermolecular_distance(mol, model, a, b)
            these_distances[b] = this_dist
            dist_sum += this_dist
            if this_dist < min_dist:
                min_dist = this_dist
        print "TDTD: ",these_distances, min_dist
        if min(these_distances, key=these_distances.get) not in mol_to_model.values():
            mol_to_model[a] = min(these_distances, key=these_distances.get)
        else:
            mol_to_model[a] = min(these_distances, key=these_distances.get)
            print mol_to_model
            raise RuntimeError('Transferring dummy tags based on distance criteria. Something assigned twice.')

    assigned = 0
    for a_mol,a_mod in mol_to_model.iteritems():
        mol[a_mol].tag = model[a_mod].tag
        assigned += 1
        print "TDT-distance  assign:",a_mod,a_mol,model[a_mod].tag
 
    if assigned != len(model_dummies):
        raise RuntimeError('Not all tags transferred!')

    return min_dist

def transfer_dummy_tags_mil53(mol,model):
    """for MIL-53 et al. transfers tags to other (M-M) dummy atoms"""
    mol_dummies = [atom.index for atom in mol if atom.symbol == 'X' and atom.mmtype == 'H_'] 
    model_dummies = model.get_atom_indices('Q')

    model_tag = model[model_dummies[0]].tag
    print "TDT-MIL53: Tag =",model_tag
    for mol_xh in mol_dummies:
        mol[mol_xh].tag = model_tag
    #Now the others
    mol_dummies = [atom.index for atom in mol if atom.symbol == 'X' and atom.mmtype != 'H_'] 
    model_dummies = model.get_atom_indices('X')
    #Now we set up a dictionary to match dummy to dummy
    mol_to_model={}
    for a in mol_dummies:
        these_distances = {}
        for b in model_dummies:
            this_dist = get_intermolecular_distance(mol, model, a, b)
            these_distances[b] = this_dist
        print "TDTD: ",these_distances
        if min(these_distances, key=these_distances.get) not in mol_to_model.values():
            mol_to_model[a] = min(these_distances, key=these_distances.get)
        else:
            mol_to_model[a] = min(these_distances, key=these_distances.get)
            print mol_to_model
            raise RuntimeError('Transferring dummy tags based on distance criteria. Something assigned twice.')

    assigned = 0
    for a_mol,a_mod in mol_to_model.iteritems():
        mol[a_mol].tag = model[a_mod].tag
        assigned += 1
        print "TDT-distance  assign:",a_mod,a_mol,model[a_mod].tag
 
    if assigned != len(model_dummies):
        raise RuntimeError('Not all tags transferred!')


    return

def transfer_dummy_tags_cpo27(mol,model):
    """For CPO-27, relies on MMtype information"""
    
    #print "Entering TCT CPO"
    #print mol.get_chemical_symbols()
    #print mol.get_atomic_numbers()
    #print mol.get_mmtypes()
    # Directly connected to metal
    model_M_indices = np.where(model.get_mmtypes() == 'H_m')[0]
    mol_M_indices = np.where(mol.get_mmtypes() == 'H_b')[0]
    #print "TDT_CPO", model_M_indices
    #print "TDT_CPO", mol_M_indices
    for a_mol,a_mod in zip(mol_M_indices,model_M_indices):
        mol[a_mol].tag = model[a_mod].tag
    print "TDT_CPO 1",mol.get_tags()
    # carboxylate
    model_CO2_index = np.where(model.get_mmtypes() == 'N_c')[0][0]
    mol_CO2_index = np.where(np.logical_and(np.array(mol.get_chemical_symbols()) == 'X', mol.get_mmtypes() == 'C_R'))[0][0]
    #print model_CO2_index,mol_CO2_index
    mol[mol_CO2_index].tag = model[model_CO2_index].tag
    print "TDT_CPO 2",mol.get_tags()
    # non-CO2 O
    model_O_index = np.where(model.get_mmtypes() == 'N')[0][0]
    mol_O_index = np.where(np.logical_and(np.array(mol.get_chemical_symbols()) == 'X', mol.get_mmtypes() == 'C_2'))[0][0]
    mol[mol_O_index].tag = model[model_O_index].tag
    print "TDT_CPO 3",mol.get_tags()
    # other dummy on non-CO2 O
    model_H1_index = np.where(model.get_mmtypes() == 'H')[0][0]
    mol_H1_index = np.where(np.logical_and(np.array(mol.get_chemical_symbols()) == 'X', mol.get_mmtypes() == 'He_'))[0][0]
    mol[mol_H1_index].tag = model[model_H1_index].tag
    print "TDT_CPO 4",mol.get_tags()
    # other dummy on non-CO2 O
    # other dummies on CO2
    model_HM_indices = np.where(model.get_mmtypes() == 'H_p')[0]
    mol_HM_indices = np.where(np.logical_and(np.array(mol.get_chemical_symbols()) =='X',mol.get_mmtypes() == 'H_'))[0]
    print model_HM_indices, mol_HM_indices
    for a_mol,a_mod in zip(mol_HM_indices,model_HM_indices):
        mol[a_mol].tag = model[a_mod].tag
    print "TDT_CPO 5",mol.get_tags()

    print mol.get_tags()

    return


def bond_extra_dummies(mof):
    """ Looks for tagged dummies that are less than 1Ang apart and have *different* tags
    and bonds them.
    This should only be called after the 'real dummies' are sorted or else weird stuff happens"""

    bond_eps = 1.15 #Ang
    #But we'll check for mmtype anyway
    mof_dummies = [atom.index for atom in mof if atom.symbol == 'X' and atom.mmtype == 'H_']
    
    #for atom in mof:
    #    print atom.index, atom.symbol, atom.mmtype
    #print mof_dummies

    write('internal.xyz',mof)
    bond_matrix = np.zeros((len(mof_dummies), len(mof_dummies)), dtype=np.float64)
    #print mof.get_distance(4,7) , mof.get_distance(4,7,mic=True)
    for a1 in xrange(len(mof_dummies) -1 ):
        for a2 in xrange(a1+1,len(mof_dummies)):
            #print mof_dummies[a1], mof_dummies[a2], mof[mof_dummies[a1]].position, mof[mof_dummies[a2]].position, mof.get_distance(mof_dummies[a1],mof_dummies[a2], mic=True) 
            bond_matrix[a1,a2] = mof.get_distance(mof_dummies[a1],mof_dummies[a2],mic=True)
            if bond_matrix[a1,a2] <bond_eps:
                print "Would form bond:, ",mof_dummies[a1], '=>' ,mof_dummies[a2], bond_matrix[a1,a2], mof[mof_dummies[a1]].tag, mof[mof_dummies[a2]].tag
            #else:
            #    print "NOT forming bond:, ",mof_dummies[a1], '=>' ,mof_dummies[a2], bond_matrix[a1,a2], mof[mof_dummies[a1]].tag, mof[mof_dummies[a2]].tag 

    

    mil_bonds = True
    while mil_bonds:
        mil_bonds=find_mil_bond(mof)

    print bond_matrix
    for a1 in xrange(len(mof_dummies) -1 ):
        for a2 in xrange(a1+1,len(mof_dummies)):
            if bond_matrix[a1,a2] < bond_eps:
                #                mof.form_bond(mof_dummies[a1],mof_dummies[a2])
                pass

    return mof

def find_mil_bond(mol):
    """Finds a single internal bond in a supercell
    Designed for MIL-53 type connectors, with a looser cutoff,
    and mic=True"""
    eps=1.15 #A
    dummy_indices= [atom.index for atom in mol if atom.symbol == 'X' and atom.mmtype == 'H_']
    for d0 in range(0,len(dummy_indices)-1):
        for d1 in range(d0+1, len(dummy_indices)):
            if mol.get_distance(dummy_indices[d0],dummy_indices[d1],mic=True) < eps: #and mol[dummy_indices[d0]].tag != mol[dummy_indices[d1]].tag:
                print "forming bond",dummy_indices[d0],dummy_indices[d1],mol.get_distance(dummy_indices[d0],dummy_indices[d1],mic=True), mol[dummy_indices[d0]].tag, mol[dummy_indices[d1]].tag 
                mol.form_bond(dummy_indices[d0],dummy_indices[d1])
                return True
    return False

#def transfer_dummy_tags(mol,model):
#    mol_dummies = mol.get_atom_indices('X')
#    model_dummies = model.get_atom_indices('X')
#    com=mol.get_center_of_mass()
#    eps=0.01
#    for a in model_dummies:
#        for b in mol_dummies:
#            #angle=get_general_angle(com,model[a].position,mol[b].position)
#            angle=get_general_angle(com,model[a].position,mol[b].position)
#            #print a,b, angle
#            if angle > pi - eps:  #angle is always positive
#                mol[b].tag = model[a].tag
#    return


#Intermolecular functions equivalent to those in atoms.py
def get_intermolecular_distance(mol0, mol1, a0, a1):
    """Return distance between two atoms in different molecules."""

    R0 = mol0.arrays['positions']
    R1 = mol1.arrays['positions']
    D = R1[a1] - R0[a0]
    return np.linalg.norm(D)

def get_general_angle(p0,p1,p2):
    """Get angle formed by three atoms.
    The atoms can be from any Atoms object, 
    
    calculate angle between the vectors p0->p1 and
    p1->p2, where each p_n is a xyz """
    # normalized vector 1->0, 1->2:
    v10 = p0 - p1 
    v12 = p2 - p1 
    #print "GGA: ",v10
    #print "GGA: ",v12
    v10 /= np.linalg.norm(v10)
    v12 /= np.linalg.norm(v12)
    angle = np.vdot(v10, v12)
    #print "GGA: ",angle
    if np.isnan(angle):
        angle2=0
    else:
        angle2 = np.arccos(angle)
    if np.isnan(angle2): #Fudge for numerical instability
        #print "HELP ME!!!! NaN"
        angle2=int(angle)
        angle2 = np.arccos(angle2)
    return angle2

def get_arbitrary_dihedral(a1,a2,a3,a4):
    """Calculate dihedral angle between four arbitrary atoms that
    need not be in the same molecule.

    Calculate dihedral angle between the vectors atom1->atom2
    and atom3->atom4, where the atomic coordinates of each atom
    are supplied. """

    # vector 0->1, 1->2, 2->3 and their normalized cross products:
    a = a2 - a1 #self.positions[list[1]] - self.positions[list[0]]
    b = a3 - a2 #self.positions[list[2]] - self.positions[list[1]]
    c = a4 - a3 #self.positions[list[3]] - self.positions[list[2]]
    bxa = np.cross(b, a)
    bxa /= np.linalg.norm(bxa)
    cxb = np.cross(c, b)
    cxb /= np.linalg.norm(cxb)
    angle = np.vdot(bxa, cxb)
    # check for numerical trouble due to finite precision:
    if angle < -1:
        angle = -1
    if angle > 1:
        angle = 1
    angle = np.arccos(angle)
    if np.vdot(bxa, c) > 0:
        angle = 2 * np.pi - angle
    return angle

def angle_2vectors(vec0,vec1):
    """Calculate angle between two vectors"""
    a = np.vdot(vec0,vec1)
    print "a =", a
    len0 = np.sqrt(np.dot(vec0,vec0))
    len1 = np.sqrt(np.dot(vec1,vec1))

    cos_theta = a / (len0 * len1)

    angle = np.arccos(cos_theta)


    return angle

def get_unique_tags(model):
    """Inspects a model and returns the number of unique tags, 
    which represent bonds between fragments, A, A' and A" are NOT unique"""
    alltags={}
    for k,v in model.iteritems():
        for tag in v.get_tags():
            #print "Found a tag", tag, tag[:1]
            if tag > 0  and tag is not None:
                if tag not in alltags:
                    alltags[tag]=[k]
                else:
                    alltags[tag].append(k)
    return alltags

def get_closest_dummy(mol,model,point):
    """given a molecule and a corresponding model and a point in that model,
    find the corresponding dummy atom in the molecule to the point in the model.
    Checks first for angle (COM,model,mol =180) then distance."""
    mol_dummies = mol.get_atom_indices('X')
    model_dummies = model.get_atom_indices('X')
    com=mol.get_center_of_mass()
    dummy_angles={}
    #print "IN GCD"
    for a in model_dummies:
        for b in mol_dummies:
            angle=get_general_angle(com,model[a].position,mol[b].position)
            print a,b,angle
    dummy_distances={}
    for a in mol_dummies:
        dist=get_intermolecular_distance(model, mol, point, a)
        dummy_distances[a] = dist 
    min_index = min(dummy_distances, key=dummy_distances.get)  
    return min_index

def find_tag(mol,tag):
    """Given a molecule and a tag, return the index of the atom that has the tag."""

    tags=mol.get_tags()
    print tag,tags
    b = [item for item in range(len(tags)) if tags[item] == tag]
    print tag,  b
    if len(b) != 1:
        raise RuntimeError('Tag, ',tag,' is defined '+`len(b)`+' times!')
    the_one_I_want=int(b[0])
    return the_one_I_want
    
def find_matching_tags(mol,tag):
    """Given a molecule and a tag, return the index of the atoms that have the tag.
    Explicitly excludes zero tags"""
    if tag != 0:
        tags=mol.get_tags()
        print "In FMT",tags
        snap = [item for item in range(len(tags)) if tags[item] == tag]
        print snap
        if len(snap) != 2:
            raise RuntimeError('Tag, ',tag,' is not present twice')
        return snap

def assemble(model,fragments):
    """Takes the model and the fragments (both dictionaries of Atoms), 
    fragments already rotated and does the translations to put the framework together"""

    build_type = model[0].info['build'].strip()

    if build_type == 'exact':
        return assemble_exact(model,fragments)

    if build_type == 'systre':
        return assemble_systre(model,fragments)
    
    raise RuntimeError('Model build type '+build_type+' not known!')

def assemble_exact(model,fragments):
    """Takes the model and the fragments (both dictionaries of Atoms), 
    fragments already rotated and puts the framework together.
    Exact assembly translates fragments such that matching tagged dummy atoms line up"""

    if len(model) != len(fragments):
        raise RuntimeError('Model has '+len(model)+' slots but there are '+len(fragments)+' fragments!')

    mof = Atoms()
    tag_dic=get_unique_tags(model)
    print "Tag_dic", tag_dic
    for frag in fragments:
        print "Begin assemble:",fragments[frag].get_tags()
    #So we set up some locking checks to make sure we place everything in a reasonable order 
    frag_locked = [False] * len(model)
    tag_locked={}
    for tag in tag_dic.keys():
        tag_locked[tag]=False
    #tag_queue=[]
    tag_queue = deque()
    initial_placement=True  
    counter=0
    while(not all(frag_locked)):
        if initial_placement:
            print "Here!"
            mof=fragments[0].copy()
            for tag in fragments[0].get_tags():
                #print tag#,len(tag)
                #if tag and not tag.endswith("\""): #len(tag)==1:
                if tag > 0 and tag is not None: 
                    tag_queue.append(tag)
                    print "Initial TQ:",tag_queue
            frag_locked[0]=True
            initial_placement=False
        else:
            current_tag=tag_queue.popleft()
            print "TQ:",tag_queue
            print "current_tag: ",current_tag 
            frags=tag_dic[current_tag]
            print "frags=", frags
            #Now either frags[0] or [1] is the next frag to place, one of them should already be done
            if frag_locked[frags[0]] == True and frag_locked[frags[1]] == False:
                next_frag=frags[1]
            elif frag_locked[frags[0]] == False and frag_locked[frags[1]] == True:
                 next_frag=frags[0]
            elif frag_locked[frags[0]] == True and frag_locked[frags[1]] == True:
                #This can and will happen if there's a closed cycle in the model, so we want to warn and lock the offending tag
                print 'WARNING: Both fragments, '+`frags[0]`+' and '+`frags[1]`+' associated with current tag, '+`current_tag`+' have been placed!\n Locking tag and moving on'
                tag_locked[current_tag]=True
                continue 
                raise RuntimeError('Both frag'+`frags[0]`+' and frag'+`frags[1]`+' have been placed!')
            elif frag_locked[frags[0]] == False and frag_locked[frags[1]] == False:
                raise RuntimeError('Neither frag'+`frags[0]`+' or frag'+`frags[1]`+' can be placed!')
    
            joiner0=find_tag(mof,current_tag)
            joiner1=find_tag(fragments[next_frag],current_tag)
            #temp=fragments[next_frag].copy() #copy then translate
            #outfile='assemble_frag_B'+`next_frag`+'.xyz'
            #write(outfile,temp)
#            print "translate vector=", mof.positions[joiner0]-fragments[next_frag].positions[joiner1]
            #temp.translate(fragments[next_frag].positions[joiner1]-mof.positions[joiner0])
            #temp.translate(mof.positions[joiner0]-fragments[next_frag].positions[joiner1]) #copy then translate
            fragments[next_frag].translate(mof.positions[joiner0]-fragments[next_frag].positions[joiner1]) #translate then copy
            temp=fragments[next_frag].copy() #translate then copy
            #outfile='assemble_frag_A'+`next_frag`+'.xyz'
            #write(outfile,temp)
            mof+=temp
            #outfile='assemble'+`counter`+'.xyz'
            #write(outfile,mof)
            counter +=1
            for tag in fragments[next_frag].get_tags():
                print "Next tags are:", fragments[next_frag].get_tags()
                print "current tag is:", tag
                #if len(tag)==1 and tag not in tag_queue and tag is not current_tag: #len=1 test won't work
                #if not tag.endswith("\"")  and tag != '' and not tag_locked[tag] and tag not in tag_queue and tag is not current_tag:
                if tag is not None and tag > 0 and not tag_locked[tag] and tag not in tag_queue and tag != current_tag:
                    print "appending: ", tag
                    tag_queue.append(tag)
                    print "TQ:",tag_queue
                    print "TL:",tag_locked
            frag_locked[next_frag]=True
            tag_locked[current_tag]=True

    #MAA 30/01 
    #Being fully evil and diabling the tests below, because they fail for cycles. FIX THIS
    #if tag_queue: 
    #    raise RuntimeError('Some tags still not placed!'+`tag_queue`)

    #if(not all(tag_locked)):
    #        raise RuntimeError('Some fragments not placed!'+`tag_locked`+'!')
    #print "Yibbida, yibbida, yibbida..."        
    return mof 

def assemble_systre(model,fragments):
    """Takes the model and the fragments (both dictionaries of Atoms),
    fragments already rotated and puts the framework together.
    Systre assembly does NOT translate fragments. Tags are matched and
    dummy atoms are removed, updating the bondlists in the process."""

    if len(model) != len(fragments):
        raise RuntimeError('Model has '+len(model)+' slots but there are '+len(fragments)+' fragments!')

    mof = Atoms()
    mof.set_cell(model[0].cell)
    #tag_dic=get_unique_tags(model)
    #print "Tag_dic", tag_dic
    #Now for systre build no translation is done, so things aren't order-dependent
    #Let's just walk through the frags
    for frag in fragments:
        print "Begin systre-style assemble:",fragments[frag].get_tags()
        mof += fragments[frag]

        outfile='assemble'+`frag`+'.xyz'
        write(outfile,mof)
    return mof

def bond_frame(mof, periodic=True):
    """Takes an assembled framework and forms all the necessary bonds by matching tags.
    *If optional periodic argument is True, includes bonds across PBC."""

    tags=mof.get_tags()
    unique_tags=set(tags)
    unique_tags.discard(0)
    #print tags
    #print "BF",unique_tags
    for tag in unique_tags:
        #if (not periodic) and (not tag.endswith("\"")): old, string way
        if (not periodic) and (not tag < 0): 
            print "NP",tag
            indices=find_matching_tags(mof,tag)
            index0=int(indices[0])
            index1=int(indices[1])
            print  tag,index0,index1
            mof.form_bond(index0,index1)
        elif periodic:
            indices=find_matching_tags(mof,tag)
            index0=int(indices[0])
            index1=int(indices[1])
            #print  tag,index0,index1
            mof.form_bond(index0,index1)

        #tmp_file=tag
        #tmp_file+='.inp'
        #tmp2_file=tag
        #tmp2_file+='.xyz'
        #write(tmp_file,mof)
        #write(tmp2_file,mof)
    return mof


def frame_cell(model,fragments):  
    """Takes the model and the fragments (both dictionaries of Atoms), 
    and works out the cell""" 

    if len(model) != len(fragments):
        raise RuntimeError('Model has '+len(model)+' slots but there are '+len(fragments)+' fragments!')
    real_cell = np.array([[0.0,0.0,0.0],[0.0,0.0,0.0],[0.0,0.0,0.0]])
    model_cell = model[0].get_cell() #assuming it's a unit cell
    axis_scale = [0,0,0]
    dummy_mol = Atoms()
    for obj in range(0,len(model)):
        print "FRAG ",obj
        #Need to determine the min and max only of the dummies in the real mol
        dummy_mol+=fragments[obj].copy()
    #write('assembled_mol.xyz',dummy_mol)
    del dummy_mol[[atom.index for atom in dummy_mol if atom.symbol!='X']]
    write('dummy_mol.xyz',dummy_mol)
   
    for axis in range(0,3):
        dummy_proj=[]
        for dummy in dummy_mol:
            #print dummy.position
            proj=np.dot(model_cell[axis],dummy.position)
            print "proj=",proj
            dummy_proj.append(proj)
        axis_proj=max(dummy_proj)-min(dummy_proj)
        print "AP=",axis,axis_proj
        axis_scale[axis]+=axis_proj
    print "AS=",axis_scale

    print real_cell
    for axis in range(0,3):
        if 'cell_scaling' in model[0].info:
            real_cell[axis]=model_cell[axis]*axis_scale[axis]*model[0].info['cell_scaling'][axis]
        else:
            print model_cell[axis], axis_scale[axis]
            real_cell[axis]=model_cell[axis]*axis_scale[axis]
    print real_cell

    #print "AS=",axis_scale
    #print real_cell

    return real_cell
    #print real_cell

def make_supercell(mol,v):
    """Takes an assembled, but not pbc-bonded framework and copies it to make a supercell"""
    eps = 1.0 #Ang 
    if isinstance(v, int):
            v = (v, v, v)    
    cell=mol.get_cell()
    #vec=[2,0,0]
    print "cell is:"
    print cell
    print cell*v
    if np.array_equal(cell,np.eye(3)):
        raise RuntimeError('mol cell has not been changed from the default value' )
    elif np.sqrt(np.dot(cell[2], cell[2])) == 0:
        #We need to invent a c-vector
        mol_height = max(mol.positions[:,2]) - min(mol.positions[:,2])
        print "mol_height = " ,mol_height
        if mol_height < 1.0:
            print "top"
            interlayer_dist = 3.5
        else:
            print "else"
            interlayer_dist = mol_height + 3.0 #
    else:
        #print "else"
        interlayer_dist = cell[2,2]
    cell[2,2] = interlayer_dist        
    bigmol = mol.copy()
    #Now we need to add new cells one at a time and update the bondlists each time or else we'll have a non-unique mapping
    for m0 in range(v[0]):
        for m1 in range(v[1]):
            for m2 in range(v[2]):
                image=mol.copy()
                vec=[m0,m1,m2]
                update_image_tags(image,vec)
                if any (vec): #don't copy and translate the 0,0,0 case
                    #for f in range(0,3):
                    #    print "CV", cell[f,:]
                    #print m0,m1,m2,": Translation",np.dot(cell,vec)
                    image.translate(np.dot(cell,vec))
                    bigmol += image
                    bigmol.set_current_indices(range(1,len(bigmol)+1))
                    bigmol.update_bondlists_add()

    #bigmol.set_cell(np.dot(cell,v)) #Wrong!
    bigmol.set_cell(np.array([v[c] * cell[c] for c in range(3)]))
    print "cell was:"
    print cell
    print "cell is now:"
    print bigmol.cell
    #write('bigmol.xyz',bigmol)
    #Now detect coincident atoms and check for dummyness and tags
    #dmat=distance_matrix(bigmol)
    internal_bonds=True
    while internal_bonds:
        internal_bonds=find_internal_bond(bigmol)
    pbc_bonds=True
    #write('bigmol2.xyz',bigmol)
    #write('bigmol2.inp',bigmol)
    while pbc_bonds:
        pbc_bonds=find_pbc_bond(bigmol)
    
    return bigmol

def update_image_tags(mol,vec):
    """Update all tags on an image with the translation. 
    Uses 0.1 for x, 0.2 for y and 0.4 for z"""
    # OLD i.e. tags A,B,C with vec=[0,1,1] => Ayz, Byz, Cyz"""
    newtag=0
    dimensions=[1, 2, 4] #=> [x,y,z]
    #print vec
    for a in range(len(vec)):
        if vec[a]:
            newtag+=dimensions[a]*10**-vec[a] #PBC tags are -ve
    #print newtag
    for a in mol:
        if a.tag and a.tag != 0:
            if a.tag > 0:
                a.tag+=newtag
            elif a.tag < 0:
                a.tag -=newtag

def remove_banquo(mol):
    """Removes any Bq atoms from structure. Bq is used for an optional dummy atom.
       Most common usage is for connectors that may have attached solvent"""

    bq_present = True
    while bq_present:
        bq_present = pop_bq(mol)

    return False

def pop_bq(mol):
    """Accessory function for remove_banquo: removes a single Bq atom from structure."""

    bq_indices = [atom.index for atom in mol if atom.symbol=='Bq']
    for bq in range(len(bq_indices)):
        #Need to delete the bond to this atom, or else update_bondlists_pop will fail
        bq_index = bq_indices[0] #the first one
        for bond in mol[bq_index].bondlist.keys():
            print "Bond is ", bond
            print "and atom ", bond, "has bondlist ",mol[bond -1].bondlist
            mol[bond -1].bondlist.pop(bq_index+1, None)
            print "Popping bond to ",bq_index+1, " from atom ",bond -1
        mol.pop(bq_index)
        return True
    return False


def find_internal_bond(mol):
    """Finds a single internal bond in a supercell"""
    eps=1.0 #A
    dummy_indices= [atom.index for atom in mol if atom.symbol=='X']
    for d0 in range(0,len(dummy_indices)-1):
        for d1 in range(d0+1, len(dummy_indices)):
            if mol.get_distance(dummy_indices[d0],dummy_indices[d1]) < eps:
                #print "forming bond",dummy_indices[d0],dummy_indices[d1],mol.get_distance(dummy_indices[d0],dummy_indices[d1])
                mol.form_bond(dummy_indices[d0],dummy_indices[d1])
                return True
    return False

def find_pbc_bond(mol):
    """Finds a single pbc bond in a supercell"""
    #Find a tag without an xyz, find the equivalent tag with an xyz, bond it and return
    dimensions=set(['x','y','z'])
    #floor to remove integer, then multiply by 10 repeatedly until diff is exactly zero
    eps = 0.5
    angle_eps = 0.002
    

    #for atom in mol:
    #    if atom.symbol =='X':
    #        print atom.index,atom.position,atom.tag, atom.bondlist
    #return False 
    #print mol.get_cell()
    cell_dims = np.zeros(3)
    for i in range(3):
        cell_dims[i] = np.sqrt(np.dot(mol.cell[i], mol.cell[i]))
    print "cell_dims = ",cell_dims

    dummy_indices= [atom.index for atom in mol if atom.symbol=='X']
    for d0 in range(0,len(dummy_indices)-1):
        for d1 in range(d0+1, len(dummy_indices)):
            #We get the two tags and see if they differ by a single character x,y or z
            tag0=mol[dummy_indices[d0]].tag
            tag1=mol[dummy_indices[d1]].tag
            #If tag is the same, then it's possible that these are two tags that match up across PBC
            if tag0 == tag1:
                this_angle=100
                #Checking for dist using mic doesn't work, it has a fit at two things being in the same place
                this_dist=mol.get_distance(dummy_indices[d0],dummy_indices[d1])
                #if we check for the dummy closest to zero, we can test only for zero angle
                for a in range(3):
                    print "a = ", a , "this_dist = ", this_dist, " - ", cell_dims[a], " = ", abs(this_dist - cell_dims[a])
                    if abs(this_dist - cell_dims[a]) < eps*1.5:
                        vec = mol[dummy_indices[d1]].position - mol[dummy_indices[d0]].position
                        for i in range(len(vec)):
                            if vec[i] < 0:
                                vec[i] = -vec[i] #ensures always in +ve octant
                        this_angle = angle_2vectors(vec , mol.cell[a])
                        print "Angle = ", this_angle
                        print "Dist = ", this_dist
                        if this_angle < eps:
                            #then this vector is parallel to cell vector. i.e. Join these two tags
                            print "forming PBC bond",dummy_indices[d0],dummy_indices[d1],mol.get_distance(dummy_indices[d0],dummy_indices[d1])
                            mol.form_bond(dummy_indices[d0],dummy_indices[d1])
                            return True

                #First check that my distance is roughly the same as one of the cell_dims
                #if any cell_dims - dist_
            #diff= (set(tag0) - set(tag1))
        #    diff= set(tag0).symmetric_difference(set(tag1))
        #    #print set(tag0),set(tag1),len(diff), diff
        #    if (len(diff) == 1) and diff.issubset(dimensions):
        #        #a,=diff unpacks the diff set
        #        dist=mol.get_distance(dummy_indices[d0],dummy_indices[d1])
        #        dist_test=abs(mol.get_cell()-dist) < eps
        #        #print dist_test
        #        if dist_test.any(): 
        #            #if (len(diff) == 1) and diff.issubset(dimensions):
        #            print "forming PBC bond",dummy_indices[d0],dummy_indices[d1],mol.get_distance(dummy_indices[d0],dummy_indices[d1])
        #            mol.form_bond(dummy_indices[d0],dummy_indices[d1])
        #            return True
    return False


                
def distance_matrix(mol):
    """Takes a mol and produces a symmetric distance matrix"""
    dist_mat=np.zeros((len(mol),len(mol)))
    for a0 in range(0,len(mol)):
        for a1 in range(a0,len(mol)):
            dist_mat[a0,a1]=mol.get_distance(a0,a1)
            dist_mat[a1,a0]=dist_mat[a0,a1]
    return dist_mat

def furthest_real(mol):
    """Takes a mol and returns the index of the real atom (not dummy)
    furthest away from the COM"""
    
    com=mol.get_center_of_mass()
    dist_array=np.zeros(len(mol))
    for a in range(0,len(mol)):
        if mol[a].symbol  != 'X' :
            D=mol.positions[a]-com
            dist_array[a]=np.linalg.norm(D)
    return np.argmax(dist_array)


def furthest_dummy(mol):
    """Takes a mol and returns the index of the dummy atom
    furthest away from the COM"""
    
    com=mol.get_center_of_mass()
    dist_array=np.zeros(len(mol))
    for a in range(0,len(mol)):
        if mol[a].symbol  == 'X' :
            D=mol.positions[a]-com
            dist_array[a]=np.linalg.norm(D)
    return np.argmax(dist_array)

