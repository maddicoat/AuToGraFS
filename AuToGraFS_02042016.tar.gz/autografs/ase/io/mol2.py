from ase.atoms import Atoms
import numpy as np

def read_mol2(fileobj, index=-1):
    """Read a Tripos mol2 file. 
    Reads only MOLECULE, ATOM and BOND sections
    Written particularly for the mol2 output of Avogadro
    but should be compliant with the standard:
    http://www.tripos.com/data/support/mol2.pdf
    Currently converts SYBYL atom types to UFF atom types. Make this optional?"""

    if isinstance(fileobj, str):
        fileobj = open(fileobj)

    full_file = fileobj.readlines()
    fileobj.close()

    lines = []
    for line in full_file:
        if '#' in line:
            pass
        else:
            lines.append(line.strip())


    index = lines.index("@<TRIPOS>MOLECULE")
    mol_name = lines[index+1]
    try:
        num_atoms, num_bonds, num_subst,  num_feat, num_sets = [int(n) for n in lines[index+2].split()] 
    except ValueError:
        num_atoms, num_bonds = [int(n) for n in lines[index+2].split()]
    #skipping parsing of molecule type, charge type, status bits (if any), and comment
    
    positions = []
    symbols = []
    charges = []
    mmtypes = []
    bondlists = []

    index = lines.index("@<TRIPOS>ATOM")
    for i in range(num_atoms):
        this_line = lines[index+1+i].split()
        this_symbol = this_line[1]
        symbol = ''.join(i for i in this_symbol if not i.isdigit())
        x, y, z = this_line[2:5]
        sybyl_mmtype = this_line[5]
        try:
            subst_id, subst_name = this_line[6:8]
            charge = this_line[8]
        except ValueError:
            charge = 0.0
        #print symbol, x,y,z, sybyl_mmtype, charge
        symbols.append(symbol.title())
        positions.append([float(x), float(y), float(z)])
        charges.append(float(charge))
        try:
            uff_mmtype = sybyl2uff_mmtypes[sybyl_mmtype]
            #print sybyl_mmtype, "=>", uff_mmtype
        except KeyError:
            uff_mmtype = ''        
        mmtypes.append(uff_mmtype)

    bond_matrix = np.zeros((num_atoms+1,num_atoms+1)) #ignore the zero index
    index = lines.index("@<TRIPOS>BOND")
    for i in range(num_bonds):
        junk, a, b, bo = lines[index+1+i].split()[:4]
        if bo.lower() == 'ar':
            bo = 1.5
        elif bo.lower() == 'am':
            bo = 1.5
        elif bo.lower() == 'du':
            bo = 1
        elif bo.lower() == 'un':
            bo = 0.5
        elif bo.lower() == 'nc':
            bo = 0.25
        else:
            bo = int(bo)
        bond_matrix[int(a),int(b)] = bo
        bond_matrix[int(b),int(a)] = bo

    for atom in range(1,num_atoms+1):
        bonddict={}
        for a2 in range(1,num_atoms+1):
            if bond_matrix[atom,a2]:
                bonddict[a2]=bond_matrix[atom,a2]
        bondlists.append(bonddict) 
        
    atoms = Atoms(positions = positions, symbols = symbols, mmtypes = mmtypes, charges=charges, bondlists = bondlists)

    return atoms

    
#Not quite complete: SYBYL 'Any", 'Het' etc. not covered
sybyl2uff_mmtypes = {
# SYBYL     :  UFF
    'H'     : 'H_',
    'C.3'   : 'C_3',
    'C.2'   : 'C_2',
    'C.1'   : 'C_1',
    'C.ar'  : 'C_R',
    'N.3'   : 'N_3',
    'N.2'   : 'N_2',
    'N.1'   : 'N_1',
    'N.ar'  : 'N_R',
    'N.am'  : 'N_R',
    'N.pl3' : 'N_R',
    'N.4'   : 'N_3',
    'O.3'   : 'O_3',
    'O.2'   : 'O_1',
    'O.co2' : 'O_2',
    'S.3'   : 'S_3+6',  #Asusmption
    'S.2'   : 'S_2',
    'S.O'   : 'S_R',    #sulfoxide
    'S.O2'  : 'S_3+4',  #sulfone
    'F'     : 'F_',
    'Cl'    : 'Cl',
    'Br'    : 'Br',
    'I'     : 'I_',
    'P.3'   : 'P_3+5',
    'Li'    : 'Li',
    'Na'    : 'Na',
    'Mg'    : 'Mg3+2',
    'Al'    : 'Al6+3',  #Assumption
    'Si'    : 'Si3',
    'K'     : 'K_',
    'Ca'    : 'Ca6+2',
    'Cr.th' : '',       #None exists
    'Cr.oh' : 'Cr4+2',  #Mega-assumption
    'Fe'    : 'Fe6+3',  #Mega-assumption
    'Mn'    : 'Mn6+3',  #Mega-assumption
    'Co.oh' : 'Co4+2',  #This is an assumption 
    'Cu'    : 'Cu4+2',  #This is an assumption, there is also an tetrahedral parameter (Rappe)
    'Zn'    : 'Zn4+2',  #This is an assumption, there is also an tetrahedral parameter (Rappe)
    'Se'    : 'Se3+2',
    'Mo'    : 'Mo6+6', #This is an assumption, there is also a tetrahedral parameter
    'Sn'    : 'Sn3', #
}


        
