
def align_hexagon(mol,model): #New 08/04/2014
    """Moves COM_mol to COM_model and then rotates the molecule to align the dummies.
    We find the midpoint of each pair of tags and then align like a triangle.""" # Hexagons are often irregular
    eps = 0.02 #on agles, about 1 deg
    model_com = model.get_center_of_mass()
    mol_com = mol.get_center_of_mass()
    mol.translate(model_com - mol_com)
    ####
    print "model MoI:"
    print model.get_masses()
    #need to alter our dummy masses here
    new_model_masses = []
    for m in model:
        if m.symbol == "Q":
            new_model_masses.append(1000.0)
        elif m.symbol == "X":
            new_model_masses.append(10.0)
        else:
            new_model_masses.append(None)
    model.set_masses(new_model_masses)
    print model.get_masses()
    model_moi = model.get_moments_of_inertia(vectors=True)
    print model.get_moments_of_inertia(vectors=True)
    print model.get_moments_of_inertia(vectors=True)[0]
    #need to alter our dummy masses here
    new_mol_masses = []
    for m in mol:
        if m.symbol == "Q":
             new_mol_masses.append(1000.0)
        elif m.symbol == "X":
             new_mol_masses.append(100.0)
        else:
             new_mol_masses.append(0.0)
    mol.set_masses(new_mol_masses)
    print "mol MoI:"
    print mol.get_moments_of_inertia(vectors=True)
    mol_moi = mol.get_moments_of_inertia(vectors=True)
    ###
    #now determine position of max and min eigenvalues
    model_max_evalue = np.argmax(model.get_moments_of_inertia(vectors=True)[0])
    model_min_evalue = np.argmin(model.get_moments_of_inertia(vectors=True)[0])
    mol_max_evalue = np.argmax(mol.get_moments_of_inertia(vectors=True)[0])
    mol_min_evalue = np.argmin(mol.get_moments_of_inertia(vectors=True)[0])
    model_mid_evalue = 3 - (model_max_evalue + model_min_evalue)
    mol_mid_evalue = 3 - (mol_max_evalue + mol_min_evalue)
    print model_max_evalue, model_mid_evalue, model_min_evalue, mol_max_evalue, mol_mid_evalue, mol_min_evalue
    print model_max_evalue, model.get_moments_of_inertia(vectors=True)[0][2]
    print "HERE"
    print model_moi[1][2]
    print model_max_evalue, model_moi[1][model_max_evalue]
    print mol_max_evalue, mol_moi[1][mol_max_evalue]


    #write('hex_model3_aligned.xyz',model)
    #write('hex_mol3_aligned.xyz',mol)
    this_model = model.copy()
    this_com = this_model.get_center_of_mass()
    this_model.positions -= np.tile(this_com, (len(this_model), 1))
    this_model.append(Atom('Cl',position=[0,0,0]))
    this_model.append(Atom('C',position=model.get_moments_of_inertia(vectors=True)[1][model_max_evalue]))
    this_model.append(Atom('S',position=model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]))
    this_model.append(Atom('O',position=model.get_moments_of_inertia(vectors=True)[1][model_mid_evalue]))
    write('hex_model.xyz',this_model)
    
    this_mol = mol.copy()
    this_com = this_mol.get_center_of_mass()
    this_mol.positions -= np.tile(this_com, (len(this_mol), 1))
    this_mol.append(Atom('Cl',position=[0,0,0]))
    this_mol.append(Atom('C',position=mol.get_moments_of_inertia(vectors=True)[1][mol_max_evalue]))
    this_mol.append(Atom('S',position=mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue]))
    this_mol.append(Atom('O',position=mol.get_moments_of_inertia(vectors=True)[1][mol_mid_evalue]))
    write('hex_mol.xyz',this_mol)
    
    ##Now align max to max
    write('hex_model3_prealigned.xyz',model+mol)
    #write('hex_mol3_prealigned.xyz',mol)
    moi_mol = Atoms()
    moi_mol.append(Atom('Cl',position=[0,0,0]))
    moi_mol.append(Atom('C',position=model.get_moments_of_inertia(vectors=True)[1][model_max_evalue]))
    moi_mol.append(Atom('S',position=model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]))
    moi_mol.append(Atom('O',position=model.get_moments_of_inertia(vectors=True)[1][model_mid_evalue]))
    mol.rotate(mol_moi[1][mol_max_evalue],model_moi[1][model_max_evalue],center=model_com)
    #moi_mol.append(Atom('O',position=model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]))
    #moi_mol.append(Atom('Ne',position=mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue]))
    #moi_mol.append(Atom('Cl',position=[0,0,0]))
    #moi_mol.append(Atom('Ar',position=mol_moi[1][mol_min_evalue]))
    write('hex_model3_semialigned.xyz',model+moi_mol)
    #write('hex_mol3_semialigned.xyz',mol)  ##UP TO HERE WORKS
    #Now we pick max distance dummy and align that, checking that vector is not parallel with max_moi
    #print model.get_moments_of_inertia(vectors=True)
    #print mol.get_moments_of_inertia(vectors=True)
    furthest_model_index = furthest_dummy(model)
    furthest_mol_index = furthest_dummy(mol)
    angle = get_general_angle(mol[furthest_mol_index].position,model[furthest_model_index].position,model_com)
    print "dummy - dummy angle =", angle
    mol.rotate(model_moi[1][model_max_evalue],angle,model_com)
    
    #Now because hexagon has symmetric moments, min and mid may be backwards

    #find angle
    #print "Angle is:"
    #print angle_2vectors(mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue],model.get_moments_of_inertia(vectors=True)[1][model_min_evalue])
    #mol.rotate(model_moi[1][model_max_evalue],-angle_2vectors(mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue],model.get_moments_of_inertia(vectors=True)[1][model_min_evalue]),center=model_com)
#    mol.rotate(mol.get_moments_of_inertia(vectors=True)[1][mol_min_evalue],model.get_moments_of_inertia(vectors=True)[1][model_min_evalue],center=model_com)
    #mol.rotate(model.get_moments_of_inertia(vectors=True)[model_min_evalue],mol.get_moments_of_inertia(vectors=True)[mol_min_evalue],center=model_com)

    print"Final moments of inertia"
    print model.get_moments_of_inertia(vectors=True)
    print mol.get_moments_of_inertia(vectors=True)
    #Now because hexagon has symmetric moments, min and mid may be backwards
    #test
#    angle = get_general_angle(mol[mol.get_atom_indices('X')[0]].position,model[1].position,model_com) #index 0 is the COM
#    print "angle between mol model dummies is:", angle
   # print "final min/mid angle", angle_2vectors(mol.get_moments_of_inertia(vectors=True)[1][mol_mid_evalue],model.get_moments_of_inertia(vectors=True)[1][model_mid_evalue])

    

    write('hex_model3_aligned.xyz',model+mol)
#    write('hex_mol3_aligned.xyz',mol)  
    
    
    ##print 'numpy angle =            ',np.arccos(np.dot(mol_moi[1][mol_min_evalue]/np.linalg.norm(mol_moi[1][mol_min_evalue]),model_moi[1][model_min_evalue]/np.linalg.norm(model_moi[1][model_min_evalue])))


    ##Now align min to min, we'll assume that the max stays where it is, because perpendicular
    #mol.rotate(mol_moi[1][mol_min_evalue],model_moi[1][model_min_evalue],center=model_com)
    #write('hex_model3_aligned.xyz',model)
    #write('hex_mol3_aligned.xyz',mol)

#    ### old code below
#    model_dummies = model.get_atom_indices('X')
#    #Now we want to pair up each of the dummy atoms
#    model_midpoints = Atoms()
#    model_Q = model.get_atom_indices('Q')
#    model_midpoints.append(model[model_Q[0]])
#    model_Xpairs = {}
#    model_mask = np.zeros(len(model), dtype=bool )
#    for a1 in range(len(model_dummies)):
#        tmp_dist = {}
#        for a2 in range(len(model_dummies)):
#            if a1 != a2:
#                dist=model.get_distance(model_dummies[a1], model_dummies[a2])
#                tmp_dist[model_dummies[a2]] = dist
#        model_Xpairs[model_dummies[a1]] = min(tmp_dist, key=tmp_dist.get)  #This should be symmetric, but maybe check it
#        print model_Xpairs
#    for a1 in model_dummies:
#        if not model_mask[a1]:
#            new_midpoint = model[a1].position + (model[model_Xpairs[a1]].position - model[a1].position)/2
#            model_midpoints.append(Atom('X',position=new_midpoint))
#            model_mask[a1] = True
#            model_mask[model_Xpairs[a1]] = True
#    #Now the molecule
#    mol_dummies = mol.get_atom_indices('X')
#    #Now we want to pair up each of the dummy atoms
#    mol_midpoints = Atoms()
#    mol_midpoints.append(model[model_Q[0]])
#    mol_Xpairs = {}
#    mol_mask = np.zeros(len(mol), dtype=bool )
#    for a1 in range(len(mol_dummies)):
#        tmp_dist = {}
#        for a2 in range(len(mol_dummies)):
#            if a1 != a2:
#                dist=mol.get_distance(mol_dummies[a1], mol_dummies[a2])
#                tmp_dist[mol_dummies[a2]] = dist
#        mol_Xpairs[mol_dummies[a1]] = min(tmp_dist, key=tmp_dist.get)  #This should be symmetric, but maybe check it
#        print mol_Xpairs
#    for a1 in mol_dummies:
#        if not mol_mask[a1]:
#            new_midpoint = mol[a1].position + (mol[mol_Xpairs[a1]].position - mol[a1].position)/2
#            mol_midpoints.append(Atom('X',position=new_midpoint))
#            mol_mask[a1] = True
#            mol_mask[mol_Xpairs[a1]] = True
#
#    #write('hex_model3_prealigned.xyz',model)
#    #write('hex_mol3_prealigned.xyz',mol)
#    #Now we can start aligning. Yay!
#    angle = get_general_angle(mol_midpoints[1].position,model_midpoints[1].position,model_com) #index 0 is the COM
#    angle2 = get_general_angle(model_midpoints[1].position,mol_midpoints[1].position,model_com) #index 0 is the COM
#    print "First angle: ",angle
#    if angle < eps and angle2 < eps: #180deg
#        print "In Hexagon 180degree case"
#        v1=mol_midpoints.positions[1]-mol_midpoints.positions[2]  #doing this, because mol_com may not be in same plane as the three dummies
#        v2=mol_midpoints.positions[2]-mol_midpoints.positions[3]
#        v = np.cross(v1, v2)
#        mol.rotate(v,pi,center=model_com)
#    elif angle > eps: #1.0deg:
#        mol.rotate(mol_midpoints[1].position-model_com,model_midpoints[1].position-model_com,center=model_com)
#    #write('hex_model3_semialigned.xyz',model)
#    #write('hex_mol3_semialigned.xyz',mol)
#    #Now second rotation
#    dih = get_arbitrary_dihedral(mol_midpoints[2].position,model_com, model_midpoints[1].position, model_midpoints[2].position)
#    #write('hex_model3_aligned.xyz',model)
#    #write('hex_mol3_aligned.xyz',mol)
#    print "Hexagon dih = ", dih
#    if not isnan(dih) and dih > eps :#1.0deg
#        mol.rotate(model_midpoints[1].position-model_com,dih,center=model_com)
#    elif isnan(dih):
#        print "nan problem here"
#        #write('hex_model3_nanaligned.xyz',model)
#        #write('hex_mol3_nanaligned.xyz',mol)


    print "about to call TDT for hexagon case"
    this_min = transfer_dummy_tags_dist(mol,model)
    print "Min = ", this_min
#    mol.rotate(mol.get_moments_of_inertia(vectors=True)[1][mol_max_evalue],pi/2,center=model_com)
#    new_min = transfer_dummy_tags_dist(mol,model)
#    print "New Min = ", new_min
#    if new_min > this_min and new_min - this_min > 0.1: #then we were right the first time
#        print "reversing rotation!"
#        mol.rotate(mol.get_moments_of_inertia(vectors=True)[1][mol_max_evalue],-pi/2,center=model_com)
#        transfer_dummy_tags_dist(mol,model)

    #print "back from TDT"
    return

