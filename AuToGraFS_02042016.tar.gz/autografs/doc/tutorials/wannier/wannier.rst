=================================
Partly occupied Wannier Functions
=================================

.. literalinclude:: benzene.py
.. literalinclude:: wannier_benzene.py
.. literalinclude:: plot_spectral_weight.py
.. literalinclude:: polyacetylene.py
.. literalinclude:: wannier_polyacetylene.py
.. literalinclude:: plot_band_structure.py
