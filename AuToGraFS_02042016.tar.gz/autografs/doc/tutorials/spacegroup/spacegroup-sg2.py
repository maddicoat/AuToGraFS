print sg
