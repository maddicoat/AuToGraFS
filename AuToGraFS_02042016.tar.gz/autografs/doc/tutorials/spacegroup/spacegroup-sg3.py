sites,kinds = sg.equivalent_sites([(0, 0, 0.5)])
