# creates:  Ag-eos.png
execfile('eos1.py')
import matplotlib
#matplotlib.use('Agg')
execfile('eos2.py')
