.. _neb2:
.. _mep2:

=====================
Dissociation tutorial
=====================


.. literalinclude:: N2Ru-Dissociation1.py


.. literalinclude:: N2Ru-Dissociation2.py
